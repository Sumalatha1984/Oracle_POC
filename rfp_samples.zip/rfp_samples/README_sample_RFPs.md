# Sample RFPs for testing (6 scenarios)

Feed each into your Blueverse run. They differ by industry, modules, constraints
and evaluation weighting, so each should produce a DIFFERENT competitor set,
capability fit, win probability and positioning.

| File | Scenario | Emphasis it tests |
|------|----------|-------------------|
| RFP_1_Automotive_Components | Discrete mfg, JIT supply chain | Manufacturing + SCM fit, migration risk |
| RFP_2_Food_Beverage | Process mfg, batch traceability | Process mfg + Quality, compliance |
| RFP_3_Pharma_MedDevice | FDA-regulated, GxP | Compliance/validation, vendor qualifications |
| RFP_4_Industrial_Equipment | Project-based, asset maintenance | Maintenance + PPM, ROI emphasis |
| RFP_5_HighTech_Electronics | Global multi-plant supply chain | SCM scale, pricing/TCO emphasis |
| RFP_6_Aerospace_Defense | Program-based, AS9100, secure | Quality/traceability, regulated experience |

What to verify after each run:
- The RFP summary picks up the right modules for that industry.
- The Competitor agent pulls live data (via the MCP DuckDuckGo tool) when the KB
  lacks coverage, and cites sources.
- The win probability and positioning differ between RFPs (not identical).
- The downloadable report reflects that specific RFP.
