"""
report_builder.py
==================
Builds a SINGLE consolidated, professionally formatted Word (.docx) report
containing the FULL output of every agent section in the pipeline.

The report is designed to be presented to government / client officials:
  - Branded cover page
  - Document control table
  - Table of contents
  - One numbered section per agent, each starting on a new page,
    with the complete markdown content rendered (headings, paragraphs,
    bold / italic, bullet & numbered lists, and tables).
  - Running header + footer with page numbers.

Only depends on python-docx (already in requirements.txt) so it runs
inside the Flask app with no extra server-side dependencies.
"""

import io
import re
from datetime import datetime

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ---------------------------------------------------------------------------
# Brand palette (matches the web UI: --primary #0078D4 / --primary-dark)
# ---------------------------------------------------------------------------
BRAND_PRIMARY = RGBColor(0x00, 0x5A, 0x9E)      # deep blue (headings)
BRAND_ACCENT = RGBColor(0x00, 0x78, 0xD4)       # bright blue (rules / accents)
TABLE_HEADER_FILL = "005A9E"                    # hex string for shading
TABLE_HEADER_TEXT = RGBColor(0xFF, 0xFF, 0xFF)
TABLE_STRIPE_FILL = "EAF2FB"
TEXT_DARK = RGBColor(0x20, 0x20, 0x20)
TEXT_MUTED = RGBColor(0x60, 0x60, 0x60)

BODY_FONT = "Calibri"
HEAD_FONT = "Calibri"

# The fixed, ordered list of sections that make up the final report.
# (key in the results dict, section title, short icon-free label)
SECTION_ORDER = [
    ("rfp_summary",            "RFP Understanding & Summary"),
    ("oracle_analysis",        "Oracle Fusion Manufacturing Capability Analysis"),
    ("competitor_analysis",    "Competitor Intelligence"),
    ("battlecards",            "Competitive Battlecards"),
    ("positioning_narratives", "Positioning & Messaging Narratives"),
    ("go_nogo",                "GO / No-Go Assessment"),
    ("recommendation",         "Strategic Recommendation & Outcomes"),
]

REPORT_TITLE = "RFP Analysis & Win Strategy Report"
REPORT_SUBTITLE = "Oracle Fusion Manufacturing \u2014 Intelligent RFP Delivery"
ORG_NAME = "LTIMindtree"


# ===========================================================================
# Low-level helpers
# ===========================================================================
# Child element ordering per ECMA-376 (subset, in document order).
_PPR_ORDER = [
    "pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr",
    "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs",
    "suppressAutoHyphens", "kinsoku", "wordWrap", "overflowPunct",
    "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
    "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents",
    "suppressOverlap", "jc", "textDirection", "textAlignment",
    "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr",
    "pPrChange",
]
_TCPR_ORDER = [
    "cnfStyle", "tcW", "gridSpan", "hMerge", "vMerge", "tcBorders", "shd",
    "noWrap", "tcMar", "textDirection", "tcFit", "vAlign", "hideMark",
    "cellIns", "cellDel", "cellMerge", "tcPrChange",
]


def _insert_ordered(parent, element, order):
    """Insert *element* into *parent* at the schema-correct position."""
    tag = element.tag.split("}")[-1]
    try:
        my_idx = order.index(tag)
    except ValueError:
        parent.append(element)
        return
    # Find first existing child that should come AFTER this element.
    for child in parent:
        child_tag = child.tag.split("}")[-1]
        if child_tag in order and order.index(child_tag) > my_idx:
            child.addprevious(element)
            return
    parent.append(element)


def _set_cell_background(cell, hex_color):
    """Apply a solid background fill to a table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    _insert_ordered(tc_pr, shd, _TCPR_ORDER)


def _set_cell_margins(cell, top=60, bottom=60, left=110, right=110):
    """Set internal padding (in twips) for a table cell."""
    tc_pr = cell._tc.get_or_add_tcPr()
    margins = OxmlElement("w:tcMar")
    # Schema order for w:tcMar is: top, left, bottom, right
    for edge, val in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        node = OxmlElement(f"w:{edge}")
        node.set(qn("w:w"), str(val))
        node.set(qn("w:type"), "dxa")
        margins.append(node)
    _insert_ordered(tc_pr, margins, _TCPR_ORDER)


def _add_bottom_border(paragraph, color="0078D4", size=12):
    """Draw a horizontal rule beneath a paragraph (used as a section divider)."""
    p_pr = paragraph._p.get_or_add_pPr()
    p_bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(size))
    bottom.set(qn("w:space"), "4")
    bottom.set(qn("w:color"), color)
    p_bdr.append(bottom)
    _insert_ordered(p_pr, p_bdr, _PPR_ORDER)


def _add_field(paragraph, instruction):
    """Insert a Word field (e.g. PAGE / NUMPAGES) into a paragraph."""
    run = paragraph.add_run()
    fld_begin = OxmlElement("w:fldChar")
    fld_begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    fld_end = OxmlElement("w:fldChar")
    fld_end.set(qn("w:fldCharType"), "end")
    run._r.append(fld_begin)
    run._r.append(instr)
    run._r.append(fld_end)
    return run


def _page_break(doc):
    doc.add_page_break()


# ===========================================================================
# Inline markdown (**bold**, *italic*) -> runs
# ===========================================================================
_INLINE_RE = re.compile(r"(\*\*.+?\*\*|__.+?__|\*.+?\*|_.+?_|`.+?`)")


def _add_inline_runs(paragraph, text, base_size=11, base_color=TEXT_DARK, base_bold=False):
    """Add text to a paragraph, honouring inline **bold** / *italic* / `code`."""
    text = text.replace("\u2022", "").strip() if False else text  # no-op guard
    parts = _INLINE_RE.split(text)
    for part in parts:
        if not part:
            continue
        bold = base_bold
        italic = False
        mono = False
        content = part
        if (part.startswith("**") and part.endswith("**")) or (part.startswith("__") and part.endswith("__")):
            bold = True
            content = part[2:-2]
        elif (part.startswith("*") and part.endswith("*")) or (part.startswith("_") and part.endswith("_")):
            italic = True
            content = part[1:-1]
        elif part.startswith("`") and part.endswith("`"):
            mono = True
            content = part[1:-1]
        run = paragraph.add_run(content)
        run.font.name = "Consolas" if mono else BODY_FONT
        run.font.size = Pt(base_size)
        run.font.bold = bold
        run.font.italic = italic
        run.font.color.rgb = base_color
    if not parts:
        run = paragraph.add_run(text)
        run.font.name = BODY_FONT
        run.font.size = Pt(base_size)
        run.font.color.rgb = base_color


# ===========================================================================
# Table parsing helpers
# ===========================================================================
def _is_table_line(line):
    s = line.strip()
    return "|" in s and s.count("|") >= 1 and len(s) > 1


def _is_separator_row(cells):
    """A markdown separator row like |---|:---:| (only dashes / colons)."""
    if not cells:
        return False
    return all(re.fullmatch(r":?-{2,}:?", c.strip()) is not None and c.strip() != "" for c in cells)


def _split_row(line):
    raw = line.strip()
    if raw.startswith("|"):
        raw = raw[1:]
    if raw.endswith("|"):
        raw = raw[:-1]
    return [c.strip() for c in raw.split("|")]


def _render_table(doc, rows):
    """Render a list of cell-lists as a styled Word table."""
    # Identify header row + separator
    header = None
    body = []
    if len(rows) >= 2 and _is_separator_row(rows[1]):
        header = rows[0]
        body = rows[2:]
    else:
        # No separator -> treat first row as header anyway for readability
        header = rows[0]
        body = rows[1:]

    n_cols = max(len(header), *(len(r) for r in body)) if body else len(header)
    n_cols = max(n_cols, 1)

    table = doc.add_table(rows=0, cols=n_cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    try:
        table.style = "Table Grid"
    except KeyError:
        pass
    table.autofit = True

    def _fill_row(cells, is_header=False, stripe=False):
        row = table.add_row()
        for c_idx in range(n_cols):
            cell = row.cells[c_idx]
            txt = cells[c_idx] if c_idx < len(cells) else ""
            cell.text = ""
            para = cell.paragraphs[0]
            para.paragraph_format.space_before = Pt(1)
            para.paragraph_format.space_after = Pt(1)
            _add_inline_runs(
                para, txt,
                base_size=9.5,
                base_color=TABLE_HEADER_TEXT if is_header else TEXT_DARK,
                base_bold=is_header,
            )
            _set_cell_margins(cell)
            if is_header:
                _set_cell_background(cell, TABLE_HEADER_FILL)
            elif stripe:
                _set_cell_background(cell, TABLE_STRIPE_FILL)

    _fill_row(header, is_header=True)
    for i, r in enumerate(body):
        _fill_row(r, is_header=False, stripe=(i % 2 == 1))

    doc.add_paragraph().paragraph_format.space_after = Pt(4)


# ===========================================================================
# Markdown block renderer
# ===========================================================================
_HEADING_SIZES = {1: 16, 2: 14, 3: 12.5, 4: 11.5}


def _render_markdown(doc, text):
    """Render a markdown string into the document body."""
    if not text or not text.strip():
        p = doc.add_paragraph()
        run = p.add_run("No data available for this section.")
        run.font.italic = True
        run.font.color.rgb = TEXT_MUTED
        return

    # Normalise line endings and strip code fences
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"```[a-zA-Z]*\n?", "", text)

    lines = text.split("\n")
    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        # --- blank line ---
        if not stripped:
            i += 1
            continue

        # --- table block ---
        if _is_table_line(line):
            block = []
            j = i
            while j < n and _is_table_line(lines[j]):
                block.append(_split_row(lines[j]))
                j += 1
            # need at least one usable row with >=2 columns
            usable = [r for r in block if len(r) >= 1]
            if usable and max(len(r) for r in usable) >= 2:
                _render_table(doc, block)
                i = j
                continue
            # otherwise fall through and treat as text

        # --- heading ---
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level = min(len(m.group(1)), 4)
            head_text = m.group(2).strip().strip("*")
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(10 if level <= 2 else 6)
            p.paragraph_format.space_after = Pt(4)
            p.paragraph_format.keep_with_next = True
            run = p.add_run(head_text)
            run.font.name = HEAD_FONT
            run.font.bold = True
            run.font.size = Pt(_HEADING_SIZES.get(level, 11))
            run.font.color.rgb = BRAND_PRIMARY if level <= 2 else BRAND_ACCENT
            i += 1
            continue

        # --- horizontal rule ---
        if re.fullmatch(r"(\*\s*){3,}|(-\s*){3,}|(_\s*){3,}", stripped):
            p = doc.add_paragraph()
            _add_bottom_border(p, color="CCCCCC", size=6)
            i += 1
            continue

        # --- bullet list item ---
        mb = re.match(r"^[-*\u2022\u2023\u25CF\u25E6]\s+(.*)$", stripped)
        if mb:
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.space_after = Pt(2)
            _add_inline_runs(p, mb.group(1))
            i += 1
            continue

        # --- numbered list item ---
        mn = re.match(r"^(\d+)[.)]\s+(.*)$", stripped)
        if mn:
            p = doc.add_paragraph(style="List Number")
            p.paragraph_format.space_after = Pt(2)
            _add_inline_runs(p, mn.group(2))
            i += 1
            continue

        # --- normal paragraph (merge consecutive non-structural lines) ---
        para_lines = [stripped]
        j = i + 1
        while j < n:
            nxt = lines[j].strip()
            if (not nxt or _is_table_line(lines[j])
                    or re.match(r"^#{1,6}\s+", nxt)
                    or re.match(r"^[-*\u2022\u2023\u25CF\u25E6]\s+", nxt)
                    or re.match(r"^\d+[.)]\s+", nxt)):
                break
            para_lines.append(nxt)
            j += 1
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.MULTIPLE
        p.paragraph_format.line_spacing = 1.15
        _add_inline_runs(p, " ".join(para_lines))
        i = j


# ===========================================================================
# Document scaffolding (styles, cover, headers/footers, TOC)
# ===========================================================================
def _configure_styles(doc):
    normal = doc.styles["Normal"]
    normal.font.name = BODY_FONT
    normal.font.size = Pt(11)
    normal.font.color.rgb = TEXT_DARK

    # python-docx's default template ships a <w:zoom/> without the required
    # w:percent attribute, which some strict validators reject. Set it.
    settings = doc.settings.element
    zoom = settings.find(qn("w:zoom"))
    if zoom is None:
        zoom = OxmlElement("w:zoom")
        settings.insert(0, zoom)
    zoom.set(qn("w:percent"), "100")


def _configure_page(doc):
    section = doc.sections[0]
    # US Letter
    section.page_width = Twips(12240)
    section.page_height = Twips(15840)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.5)
    section.footer_distance = Inches(0.5)
    section.different_first_page_header_footer = True
    return section


def _build_header_footer(section, run_id):
    # ---- Running header (not on first/cover page) ----
    header = section.header
    header.is_linked_to_previous = False
    hp = header.paragraphs[0]
    hp.text = ""
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = hp.add_run(f"{REPORT_TITLE}  \u2022  {ORG_NAME}")
    run.font.size = Pt(8)
    run.font.color.rgb = TEXT_MUTED
    _add_bottom_border(hp, color="CCCCCC", size=4)

    # ---- Running footer with page numbers ----
    footer = section.footer
    footer.is_linked_to_previous = False
    fp = footer.paragraphs[0]
    fp.text = ""
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pre = fp.add_run("Page ")
    pre.font.size = Pt(8)
    pre.font.color.rgb = TEXT_MUTED
    f1 = _add_field(fp, "PAGE")
    f1.font.size = Pt(8)
    f1.font.color.rgb = TEXT_MUTED
    mid = fp.add_run(" of ")
    mid.font.size = Pt(8)
    mid.font.color.rgb = TEXT_MUTED
    f2 = _add_field(fp, "NUMPAGES")
    f2.font.size = Pt(8)
    f2.font.color.rgb = TEXT_MUTED
    tail = fp.add_run(f"    |    Run ID: {run_id}")
    tail.font.size = Pt(8)
    tail.font.color.rgb = TEXT_MUTED


def _build_cover(doc, run_id, total_seconds, source_filename):
    # Spacer
    for _ in range(3):
        doc.add_paragraph()

    # Organisation
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(ORG_NAME.upper())
    r.font.size = Pt(14)
    r.font.bold = True
    r.font.color.rgb = BRAND_ACCENT

    # Title
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    r = p.add_run(REPORT_TITLE)
    r.font.size = Pt(30)
    r.font.bold = True
    r.font.color.rgb = BRAND_PRIMARY

    # Subtitle
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(REPORT_SUBTITLE)
    r.font.size = Pt(13)
    r.font.color.rgb = TEXT_MUTED

    # Rule
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    _add_bottom_border(p, color="0078D4", size=18)

    for _ in range(6):
        doc.add_paragraph()

    # Document control table
    meta = [
        ("Prepared by", f"{ORG_NAME} \u2014 RFP Delivery AI Platform"),
        ("Source document", source_filename or "Uploaded RFP"),
        ("Date generated", datetime.now().strftime("%d %B %Y, %H:%M")),
        ("Report reference", run_id),
        ("Analysis runtime", f"{total_seconds} seconds" if total_seconds else "\u2014"),
        ("Classification", "Confidential \u2014 For Official Use"),
    ]
    table = doc.add_table(rows=0, cols=2)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    try:
        table.style = "Table Grid"
    except KeyError:
        pass
    for label, value in meta:
        row = table.add_row()
        c0, c1 = row.cells[0], row.cells[1]
        c0.width = Inches(2.2)
        c1.width = Inches(4.0)
        c0.text = ""
        c1.text = ""
        rp = c0.paragraphs[0].add_run(label)
        rp.font.bold = True
        rp.font.size = Pt(10)
        rp.font.color.rgb = TABLE_HEADER_TEXT
        _set_cell_background(c0, TABLE_HEADER_FILL)
        _set_cell_margins(c0)
        vp = c1.paragraphs[0].add_run(value)
        vp.font.size = Pt(10)
        vp.font.color.rgb = TEXT_DARK
        _set_cell_margins(c1)

    _page_break(doc)


def _build_toc(doc):
    p = doc.add_paragraph()
    r = p.add_run("Table of Contents")
    r.font.size = Pt(18)
    r.font.bold = True
    r.font.color.rgb = BRAND_PRIMARY
    p.paragraph_format.space_after = Pt(6)
    _add_bottom_border(p, color="0078D4", size=12)
    doc.add_paragraph().paragraph_format.space_after = Pt(4)

    for idx, (_key, title) in enumerate(SECTION_ORDER, start=1):
        line = doc.add_paragraph()
        line.paragraph_format.space_after = Pt(6)
        rn = line.add_run(f"{idx}.  ")
        rn.font.bold = True
        rn.font.size = Pt(11)
        rn.font.color.rgb = BRAND_ACCENT
        rt = line.add_run(title)
        rt.font.size = Pt(11)
        rt.font.color.rgb = TEXT_DARK

    note = doc.add_paragraph()
    note.paragraph_format.space_before = Pt(14)
    rn = note.add_run(
        "This report consolidates the complete output of all analysis stages "
        "into a single document. Each section below contains the full detail "
        "and checklist produced for that stage."
    )
    rn.font.italic = True
    rn.font.size = Pt(9.5)
    rn.font.color.rgb = TEXT_MUTED

    _page_break(doc)


def _strip_leading_duplicate_title(content, title):
    """If the content's first heading just repeats the section title, drop it."""
    if not content:
        return content
    lines = content.replace("\r\n", "\n").split("\n")
    idx = 0
    while idx < len(lines) and not lines[idx].strip():
        idx += 1
    if idx < len(lines):
        m = re.match(r"^#{1,6}\s+(.*)$", lines[idx].strip())
        if m:
            heading = m.group(1).strip().strip("*").lower()
            norm_title = title.lower()
            if heading == norm_title or heading.replace("&", "and") == norm_title.replace("&", "and"):
                return "\n".join(lines[idx + 1:])
    return content


def _build_section(doc, index, title, content, is_first):
    if not is_first:
        _page_break(doc)

    # Section number + title banner
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    rn = p.add_run(f"Section {index}")
    rn.font.size = Pt(10)
    rn.font.bold = True
    rn.font.color.rgb = BRAND_ACCENT

    p2 = doc.add_paragraph()
    p2.paragraph_format.space_after = Pt(8)
    rt = p2.add_run(title)
    rt.font.size = Pt(18)
    rt.font.bold = True
    rt.font.color.rgb = BRAND_PRIMARY
    _add_bottom_border(p2, color="0078D4", size=14)

    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    content = _strip_leading_duplicate_title(content, title)
    _render_markdown(doc, content)


# ===========================================================================
# Public API
# ===========================================================================
def _extract_content(results, key):
    section = results.get(key) or {}
    if isinstance(section, dict):
        return section.get("content", "") or ""
    return str(section)


def build_report(results: dict, run_id: str = None, source_filename: str = None) -> io.BytesIO:
    """Build the consolidated DOCX report and return it as an in-memory buffer."""
    results = results or {}
    meta = results.get("_meta", {}) if isinstance(results, dict) else {}
    run_id = run_id or meta.get("run_id") or datetime.now().strftime("%Y%m%d_%H%M%S")
    total_seconds = meta.get("total_seconds")

    doc = Document()
    _configure_styles(doc)
    section = _configure_page(doc)
    _build_header_footer(section, run_id)

    _build_cover(doc, run_id, total_seconds, source_filename)
    _build_toc(doc)

    first = True
    for idx, (key, title) in enumerate(SECTION_ORDER, start=1):
        content = _extract_content(results, key)
        _build_section(doc, idx, title, content, is_first=first)
        first = False

    buffer = io.BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer


def build_report_filename(run_id: str = None) -> str:
    stamp = datetime.now().strftime("%Y%m%d_%H%M")
    suffix = (run_id or stamp)
    return f"RFP_Analysis_Report_{suffix}.docx"
