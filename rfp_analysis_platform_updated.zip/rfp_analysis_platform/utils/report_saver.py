import os
import json
from utils.logger_setup import get_logger

# Determine output directory relative to this file's parent (project root)
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_OUTPUT_FOLDER = os.path.join(_PROJECT_ROOT, "outputs")

logger = get_logger("report_saver")


def save_report(run_id: str, report_name: str, content: str, full_result: dict):
    """Save agent output as both .txt and .json to the outputs folder."""
    run_dir = os.path.join(_OUTPUT_FOLDER, run_id)
    os.makedirs(run_dir, exist_ok=True)

    # Save readable text
    txt_path = os.path.join(run_dir, f"{report_name}.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write(content)
    logger.info(f"Saved: {txt_path}")

    # Save full JSON (for debugging / raw data)
    json_path = os.path.join(run_dir, f"{report_name}.json")
    serializable = _make_serializable(full_result)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(serializable, f, indent=2, ensure_ascii=False)
    logger.info(f"Saved: {json_path}")


def _make_serializable(obj):
    """Ensure object is JSON-serializable."""
    if isinstance(obj, dict):
        return {k: _make_serializable(v) for k, v in obj.items()}
    elif isinstance(obj, (list, tuple)):
        return [_make_serializable(i) for i in obj]
    elif isinstance(obj, (str, int, float, bool, type(None))):
        return obj
    else:
        return str(obj)
