from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("positioning_messaging")


class PositioningMessagingAgent(BaseAgent):
    def __init__(self):
        super().__init__("positioning_messaging", "Positioning & Messaging Agent")

    def analyze(self, rfp_summary: str, oracle_analysis: str, competitor_analysis: str) -> dict:
        prompt = (
            "You are the Positioning & Messaging Agent. Draft concise, proposal-ready "
            "positioning narratives for Oracle Fusion Manufacturing.\n"
            "Include:\n"
            "1. Executive Summary / Elevator Pitch\n"
            "2. Value Proposition Statement\n"
            "3. Key Messaging Pillars\n"
            "4. Differentiator Narratives\n"
            "5. Client Pain Points Addressed\n"
            "6. Proof Points / Case Studies References\n"
            "7. Proposal Section Recommendations\n"
            "8. Tone & Style Guidance\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:5000]}\n\n"
            f"ORACLE ANALYSIS:\n{oracle_analysis[:5000]}\n\n"
            f"COMPETITOR ANALYSIS:\n{competitor_analysis[:5000]}"
        )
        logger.info("Calling Positioning & Messaging Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"Positioning & Messaging complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
