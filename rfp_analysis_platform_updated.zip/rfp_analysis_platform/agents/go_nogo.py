from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("go_nogo")


class GoNoGoAgent(BaseAgent):
    def __init__(self):
        super().__init__("go_nogo", "GO / No-Go Agent")

    def analyze(self, rfp_summary: str, oracle_analysis: str, competitor_analysis: str) -> dict:
        prompt = (
            "You are the GO/No-Go Decision Agent. Evaluate whether LTIMindtree should "
            "pursue this RFP opportunity.\n"
            "Provide:\n"
            "1. GO / NO-GO Recommendation (clear verdict)\n"
            "2. Confidence Score (0-100%)\n"
            "3. Strategic Alignment Assessment\n"
            "4. Capability Fit Score\n"
            "5. Competitive Position Assessment\n"
            "6. Risk Assessment (High/Medium/Low with details)\n"
            "7. Resource & Effort Estimation\n"
            "8. Revenue Potential\n"
            "9. Key Decision Factors\n"
            "10. Conditions for GO (if conditional)\n"
            "11. Mitigation Strategies for Identified Risks\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:5000]}\n\n"
            f"ORACLE ANALYSIS:\n{oracle_analysis[:5000]}\n\n"
            f"COMPETITOR ANALYSIS:\n{competitor_analysis[:5000]}"
        )
        logger.info("Calling GO/No-Go Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"GO/No-Go analysis complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
