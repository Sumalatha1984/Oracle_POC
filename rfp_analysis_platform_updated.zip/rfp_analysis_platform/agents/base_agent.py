import requests
import json
import time
import traceback
from config import Config
from utils.logger_setup import get_logger

logger = get_logger("base_agent")


class BaseAgent:
    """Base class for all Blueverse agents."""

    def __init__(self, agent_key: str, display_name: str):
        self.agent_key = agent_key
        self.display_name = display_name
        cfg = Config.AGENTS.get(agent_key, {})
        self.space_name = cfg.get("space_name", "")
        self.flow_id = cfg.get("flowId", "")
        self.api_url = Config.API_URL
        self.api_token = Config.API_TOKEN

    def call(self, query: str, timeout: int = 300) -> dict:
        """Call the Blueverse chat API and return parsed response."""
        logger.info(f"[{self.display_name}] Sending request (query length={len(query)} chars)")
        start = time.time()

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_token}",
        }
        payload = {
            "query": query,
            "space_name": self.space_name,
            "flowId": self.flow_id,
        }

        try:
            resp = requests.post(
                self.api_url,
                headers=headers,
                json=payload,
                timeout=timeout,
            )
            elapsed = round(time.time() - start, 2)
            logger.info(f"[{self.display_name}] Response status={resp.status_code} time={elapsed}s")

            if resp.status_code != 200:
                error_msg = f"HTTP {resp.status_code}: {resp.text[:500]}"
                logger.error(f"[{self.display_name}] API Error: {error_msg}")
                return {"success": False, "error": error_msg, "raw": resp.text}

            data = resp.json()
            logger.info(f"[{self.display_name}] Successfully parsed JSON response")
            return {"success": True, "data": data, "elapsed_seconds": elapsed}

        except requests.exceptions.Timeout:
            logger.error(f"[{self.display_name}] Request timed out after {timeout}s")
            return {"success": False, "error": f"Request timed out after {timeout}s"}
        except requests.exceptions.ConnectionError as e:
            logger.error(f"[{self.display_name}] Connection error: {e}")
            return {"success": False, "error": f"Connection error: {str(e)}"}
        except json.JSONDecodeError as e:
            logger.error(f"[{self.display_name}] JSON decode error: {e}")
            return {"success": False, "error": f"Invalid JSON response: {str(e)}", "raw": resp.text}
        except Exception as e:
            logger.error(f"[{self.display_name}] Unexpected error: {e}\n{traceback.format_exc()}")
            return {"success": False, "error": str(e)}

    def extract_content(self, response: dict) -> str:
        """Extract the main text content from agent response.
        Override in subclass if response structure differs."""
        if not response.get("success"):
            return response.get("error", "Agent call failed.")
        data = response.get("data", {})
        # Common patterns in Blueverse responses
        if isinstance(data, dict):
            for key in ["response", "answer", "result", "message", "text", "output", "content"]:
                if key in data:
                    return str(data[key])
            return json.dumps(data, indent=2)
        return str(data)
