from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("recommendation_outcomes")


class RecommendationOutcomesAgent(BaseAgent):
    def __init__(self):
        super().__init__("recommendation_outcomes", "Recommendation Outcomes Agent")

    def analyze(self, rfp_summary: str, oracle_analysis: str,
                competitor_analysis: str, go_nogo_report: str) -> dict:
        prompt = (
            "You are the Recommendation Outcomes Agent. Synthesize all analysis inputs "
            "and provide final actionable recommendations.\n"
            "Include:\n"
            "1. Executive Recommendation Summary\n"
            "2. Overall Opportunity Score\n"
            "3. Recommended Approach & Strategy\n"
            "4. Key Win Themes to Emphasize\n"
            "5. Resource Allocation Recommendations\n"
            "6. Proposal Structure Recommendations\n"
            "7. Pricing Strategy Guidance\n"
            "8. Risk Mitigation Plan\n"
            "9. Timeline for Proposal Preparation\n"
            "10. Success Probability Assessment\n"
            "11. Next Steps & Action Items\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:4000]}\n\n"
            f"ORACLE ANALYSIS:\n{oracle_analysis[:4000]}\n\n"
            f"COMPETITOR ANALYSIS:\n{competitor_analysis[:4000]}\n\n"
            f"GO/NO-GO REPORT:\n{go_nogo_report[:4000]}"
        )
        logger.info("Calling Recommendation Outcomes Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"Recommendation Outcomes complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
