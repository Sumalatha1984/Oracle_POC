from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("rfp_understanding")


class RFPUnderstandingAgent(BaseAgent):
    def __init__(self):
        super().__init__("rfp_understanding", "RFP Understanding Agent")

    def analyze(self, rfp_text: str) -> dict:
        prompt = (
            "You are the RFP Understanding Agent. Analyze the following RFP document thoroughly.\n"
            "Provide a structured summary including:\n"
            "1. RFP Title & Issuing Organization\n"
            "2. Scope of Work\n"
            "3. Key Requirements (functional, technical, compliance)\n"
            "4. Evaluation Criteria\n"
            "5. Timeline & Milestones\n"
            "6. Budget Constraints (if mentioned)\n"
            "7. Submission Requirements\n"
            "8. Critical Success Factors\n"
            "9. Domain / Industry Focus\n"
            "10. Key Risks & Challenges\n\n"
            f"RFP DOCUMENT:\n{rfp_text[:12000]}"
        )
        logger.info("Calling RFP Understanding Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"RFP Understanding complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
