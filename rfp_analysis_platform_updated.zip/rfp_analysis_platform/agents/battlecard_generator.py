from agents.base_agent import BaseAgent
from utils.logger_setup import get_logger

logger = get_logger("battlecard_generator")


class BattlecardGeneratorAgent(BaseAgent):
    def __init__(self):
        super().__init__("battlecard_generator", "Battlecard Generator Agent")

    def analyze(self, rfp_summary: str, oracle_analysis: str, competitor_analysis: str) -> dict:
        prompt = (
            "You are the Battlecard Generator Agent. Using the inputs below, "
            "create detailed competitive battlecards.\n"
            "For each major competitor, include:\n"
            "1. Competitor Overview\n"
            "2. Head-to-Head Comparison (LTIMindtree+Oracle vs Competitor)\n"
            "3. Our Strengths vs Their Weaknesses\n"
            "4. Their Strengths vs Our Weaknesses\n"
            "5. Key Differentiators\n"
            "6. Recommended Talk Tracks / Counter-arguments\n"
            "7. Pricing Strategy Guidance\n"
            "8. Win Themes\n\n"
            f"RFP SUMMARY:\n{rfp_summary[:5000]}\n\n"
            f"ORACLE ANALYSIS:\n{oracle_analysis[:5000]}\n\n"
            f"COMPETITOR ANALYSIS:\n{competitor_analysis[:5000]}"
        )
        logger.info("Calling Battlecard Generator Agent...")
        response = self.call(prompt)
        content = self.extract_content(response)
        logger.info(f"Battlecard generation complete. Output length={len(content)} chars")
        return {
            "agent": self.display_name,
            "success": response.get("success", False),
            "content": content,
            "raw_response": response,
        }
