import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Centralized configuration loaded from .env"""

    SECRET_KEY = os.getenv("SECRET_KEY", "rfp-analysis-secret-key-2026")
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads")
    OUTPUT_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
    LOG_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50 MB max upload

    # Blueverse API
    API_URL = os.getenv("BLUEVERSE_API_URL", "")
    API_TOKEN = os.getenv("BLUEVERSE_API_TOKEN", "")

    # Agent configs  (space_name, flowId)
    AGENTS = {
        "rfp_understanding": {
            "space_name": os.getenv("RFP_UNDERSTANDING_SPACE", ""),
            "flowId": os.getenv("RFP_UNDERSTANDING_FLOW", ""),
        },
        "oracle_mfg_capability": {
            "space_name": os.getenv("ORACLE_MFG_CAPABILITY_SPACE", ""),
            "flowId": os.getenv("ORACLE_MFG_CAPABILITY_FLOW", ""),
        },
        "competitor_intelligence": {
            "space_name": os.getenv("COMPETITOR_INTELLIGENCE_SPACE", ""),
            "flowId": os.getenv("COMPETITOR_INTELLIGENCE_FLOW", ""),
        },
        "battlecard_generator": {
            "space_name": os.getenv("BATTLECARD_GENERATOR_SPACE", ""),
            "flowId": os.getenv("BATTLECARD_GENERATOR_FLOW", ""),
        },
        "positioning_messaging": {
            "space_name": os.getenv("POSITIONING_MESSAGING_SPACE", ""),
            "flowId": os.getenv("POSITIONING_MESSAGING_FLOW", ""),
        },
        "go_nogo": {
            "space_name": os.getenv("GO_NOGO_SPACE", ""),
            "flowId": os.getenv("GO_NOGO_FLOW", ""),
        },
        "recommendation_outcomes": {
            "space_name": os.getenv("RECOMMENDATION_OUTCOMES_SPACE", ""),
            "flowId": os.getenv("RECOMMENDATION_OUTCOMES_FLOW", ""),
        },
    }

    @classmethod
    def init_folders(cls):
        for folder in [cls.UPLOAD_FOLDER, cls.OUTPUT_FOLDER, cls.LOG_FOLDER]:
            os.makedirs(folder, exist_ok=True)
