# Oracle Fusion Manufacturing — RFP-Winning System

A grounded, multi-agent system that ingests an Oracle Fusion Manufacturing RFP and
produces an Oracle capability fit, competitor battlecards, a winning pitch, a
Go/No-Go decision **with a win probability**, and an actionable recommendation.

Every fact an agent asserts is **grounded** in a curated internal knowledge base
(competitor profiles, win/loss history, Oracle capability docs, case studies) — never
the live internet. This satisfies the Blueverse no-internet rule and makes the output
credible and reproducible.

## Two run modes
| Mode | What it does | When to use |
|------|--------------|-------------|
| `local` | Runs fully offline. RAG over the seeded KB + a deterministic provider. No credentials. | Demo, development, tests |
| `blueverse` | Calls the real Blueverse Foundry agents (space + flowId). | Production |

---

## 1. Setup (5 minutes)
```bash
# from the project root
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                    # defaults to PROVIDER_MODE=local
```

## 2. Run the tests (proves it works end-to-end, offline)
```bash
PROVIDER_MODE=local python -m pytest -q
```
Expected: `9 passed`. Covers the knowledge base, individual agents, the full
pipeline, and **failure isolation** (one agent failing does not crash the run).

## 3. Run end-to-end from the command line
```bash
PROVIDER_MODE=local python -m scripts.run_cli samples/sample_rfp.txt
```
Prints the win probability, decision, historical basis, competitors, and action count.

Or one command for tests + a sample run:
```bash
bash scripts/smoke_test.sh
```

## 4. Run the web app
```bash
PROVIDER_MODE=local python run.py
# open http://127.0.0.1:5000
```
Upload an RFP (`.txt/.md/.pdf/.docx`) or paste text → **Analyze**. You will see live
per-agent progress and tabbed JSON results with the grounding sources listed.

---

## 5. The pipeline (4 phases, 7 agents)
1. **RFP Understanding** → structured JSON manifest (the contract for everything downstream)
2. **Oracle MFG Capability** + **Competitor Intelligence** (parallel)
3. **Battlecard** + **Positioning** + **Go/No-Go** (parallel)
4. **Recommendation** → gaps + ordered action plan

Agents within a phase run in parallel; each call is failure-isolated.

## 6. The knowledge base (your grounding data)
Drop documents into `data/`:
- `data/competitors/*.md` — one file per competitor (`# Name`, `## Strengths`, `## Weaknesses`, `## Likely play`)
- `data/win_loss/*.json` — past bids: `{client, industry, competitor, modules, value_musd, outcome, reason}`
- `data/oracle_capability/*.md` — Oracle module capabilities (`# Module`, `## Capabilities`, `## Differentiators`)
- `data/case_studies/*.md` — references (`# Title`, `## Summary`, `## Outcome`)

The seeded content is **illustrative** — replace it with your real internal data.
Competitor data is compiled from **public sources** (sites, analyst notes, press); the
agents never fetch the internet at run time. To refresh it automatically in production,
run an ingestion job **outside** Blueverse that writes into this KB / the vector store.


## 6b. Hybrid grounding (internal KB + live web via MCP)
The knowledge base is the **primary** source. When it lacks coverage for a competitor,
the Competitor agent fills the gap with a **live web search through the governed Blueverse
MCP connector** (e.g. DuckDuckGo), then **caches the result back into the KB** so the next
run is reproducible. The **Go/No-Go probability never uses web search** — it stays on
internal win/loss data so the number is defensible.

Controls (in .env): `ENABLE_WEB_SEARCH`, `WEB_SEARCH_MODE` (local stub vs blueverse_mcp),
`MCP_SEARCH_URL`, `GAP_SCORE_THRESHOLD`, `CACHE_WEB_RESULTS`.


## 6c. Testing your agent prompts (without Blueverse)
`local` mode does NOT exercise prompts (the local provider returns canned data) —
it validates the pipeline, grounding, report and failure handling. To test the
**prompts themselves**, run them against a real model:

**Option A — Ollama (local, offline, recommended).** Install Ollama, pull a model
once (needs internet only for the pull), then run fully offline:
```
ollama pull llama3.1
# .env:
PROVIDER_MODE=llm
LLM_BASE_URL=http://localhost:11434/v1
LLM_MODEL=llama3.1
python -m scripts.run_cli samples/sample_rfp.txt
```

**Option B — any OpenAI-compatible API.** Set PROVIDER_MODE=llm, LLM_BASE_URL,
LLM_API_KEY, LLM_MODEL.

**Option C — manual.** Copy a prompt from `prompts/prompts.py` into any chat
LLM with a sample input and check the JSON.

### How to change a prompt and verify (the loop)
1. Edit the prompt constant in `prompts/prompts.py` (e.g. COMPETITOR_INTEL).
2. `python -m pytest -q`  — confirms structure/plumbing still pass (13 passed).
3. `PROVIDER_MODE=llm python -m scripts.run_cli samples/sample_rfp.txt`  — see the
   real model output and iterate on wording.
4. `python run.py` — eyeball the rendered report. Repeat.

Agent logic (retrieval, scoring) lives in `agents/pipeline_agents.py`;
the flow and the 7 agents are fixed in `agents/orchestrator.py`.

## 7. Switch to production (Blueverse)
1. In Blueverse, create the 7 agents and attach a **RAG knowledge base / MCP tool** to each
   data-hungry agent (Competitor, Oracle Capability, Positioning, Go/No-Go, Recommendation).
2. In `.env` set:
   ```
   PROVIDER_MODE=blueverse
   BLUEVERSE_BASE_URL=...     BLUEVERSE_TOKEN=...     BLUEVERSE_SPACE_NAME=...
   FLOW_RFP_UNDERSTANDING=... FLOW_ORACLE_CAPABILITY=... (etc.)
   ```
3. Serve behind a production server:
   ```bash
   pip install gunicorn
   gunicorn -w 2 -b 0.0.0.0:8000 'app:create_app()'
   ```
The agent prompts (in `prompts/prompts.py`) are the system+task prompts; keep secrets
in the environment/vault, never in the repo.

## 8. Project layout
```
config.py            settings (mode, paths, Blueverse, flow ids)
run.py               Flask entry point
prompts/prompts.py   refined agent prompts + JSON contracts + grounding rule
core/                knowledge_base (RAG) · llm_provider (Blueverse+Local) · job_store · report_saver
agents/              base_agent · pipeline_agents (7) · orchestrator (4 phases, failure-isolated)
data/                seeded knowledge base (replace with real data)
utils/file_parser    txt/md/pdf/docx extraction
app/ · templates/ · static/   Flask routes + UI (live progress, tabbed results)
tests/               unit + end-to-end + failure-isolation tests
scripts/             smoke_test.sh · run_cli.py
samples/             sample_rfp.txt
```

## Notes for production hardening (already wired or easy to extend)
- Async background job with status polling (no long blocking request).
- Per-agent failure isolation and Blueverse retry/backoff.
- Outputs persisted per run under `outputs/<job_id>/`.
- Add auth in front of the app, structured logging, and monitoring before go-live.
