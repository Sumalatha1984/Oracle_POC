"""Entry point. In production run via gunicorn: `gunicorn 'app:create_app()'`."""
from app import create_app
import config

app = create_app()

if __name__ == "__main__":
    debug = config.PROVIDER_MODE == "local"
    app.run(host="127.0.0.1", port=5000, debug=debug)
