"""Extract text from uploaded RFP files (.txt/.md/.pdf/.docx)."""
from __future__ import annotations
from pathlib import Path


def parse(path: str) -> str:
    p = Path(path)
    ext = p.suffix.lower()
    if ext in (".txt", ".md"):
        return p.read_text(encoding="utf-8", errors="ignore")
    if ext == ".docx":
        from docx import Document
        doc = Document(str(p))
        parts = [para.text for para in doc.paragraphs]
        for table in doc.tables:
            for row in table.rows:
                parts.append(" | ".join(c.text for c in row.cells))
        return "\n".join(parts)
    if ext == ".pdf":
        import pdfplumber
        out = []
        with pdfplumber.open(str(p)) as pdf:
            for page in pdf.pages:
                out.append(page.extract_text() or "")
        return "\n".join(out)
    raise ValueError(f"Unsupported file type: {ext}")
