"""The seven concrete agents. Each defines its prompt, retrieval, and a
deterministic grounded local_payload for offline mode."""
from __future__ import annotations
import json
import re
from typing import Dict, List

from agents.base_agent import BaseAgent, md_sections, bullets, MODULES
from prompts import prompts as P


def _sentences(text: str) -> List[str]:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n", text) if s.strip()]


class RFPUnderstandingAgent(BaseAgent):
    key, name = "rfp_understanding", "RFP Understanding Agent"

    def build_prompt(self, inputs):
        return P.RFP_UNDERSTANDING.format(rule=P.GROUNDING_RULE, rfp_text=inputs["rfp_text"][:16000])

    def local_payload(self, inputs, context, kb):
        text = inputs["rfp_text"]
        low = text.lower()
        sents = _sentences(text)
        modules = [m for m in MODULES if m.lower() in low]
        must = [s for s in sents if re.search(r"\b(must|shall|require|mandatory)\b", s, re.I)][:8]
        nice = [s for s in sents if re.search(r"\b(nice to have|preferred|optional|desirable)\b", s, re.I)][:5]
        cons = [s for s in sents if re.search(r"\b(timeline|budget|go-live|deadline|integration|compliance|migration)\b", s, re.I)][:6]
        evals = [s for s in sents if re.search(r"\b(evaluat|criteria|scoring|weight|points)\b", s, re.I)][:6]
        risks = [s for s in sents if re.search(r"\b(risk|legacy|aging|disconnect|manual|delay)\b", s, re.I)][:5]
        return {
            "opportunity": (sents[0] if sents else "Oracle Fusion Manufacturing modernization")[:160],
            "client_industry": "Manufacturing",
            "scope_modules": modules or ["Manufacturing", "SCM", "Financials"],
            "must_have": must or ["Cloud ERP for manufacturing operations"],
            "nice_to_have": nice,
            "constraints": cons,
            "evaluation_factors": evals or ["Technical approach", "Functional fit", "Pricing & value"],
            "risk_flags": risks,
            "manufacturing_fit": "Strong fit: requirements map to Oracle Fusion Cloud Manufacturing, SCM and Financials.",
            "pursuit_focus": "Demonstrate proven Oracle Fusion manufacturing delivery and lowest-risk migration.",
        }


class OracleCapabilityAgent(BaseAgent):
    key, name = "oracle_capability", "Oracle MFG Capability Agent"
    collections = ["oracle_capability"]

    def retrieve_query(self, inputs):
        m = inputs.get("manifest", {})
        return " ".join(m.get("must_have", []) + m.get("scope_modules", []))

    def build_prompt(self, inputs):
        return P.ORACLE_CAPABILITY.format(rule=P.GROUNDING_RULE,
                                          manifest=json.dumps(inputs.get("manifest", {})))

    def local_payload(self, inputs, context, kb):
        manifest = inputs.get("manifest", {})
        fits = []
        strong = 0
        for req in (manifest.get("must_have") or [])[:8]:
            hits = kb.retrieve("oracle_capability", req, k=1)
            if hits and hits[0]["score"] > 0:
                sec = md_sections(hits[0]["text"])
                module = sec.get("_title", "Oracle Fusion")
                fit = "strong"
                strong += 1
            else:
                module, fit = "Oracle Fusion (general)", "partial"
            fits.append({"requirement": req[:120], "oracle_module": module,
                         "fit": fit, "evidence_source": hits[0]["source"] if hits else "n/a"})
        score = int(60 + 35 * (strong / max(len(fits), 1)))
        diffs = []
        for h in kb.retrieve("oracle_capability", "differentiator unified cloud", k=3):
            diffs += bullets(md_sections(h["text"]).get("differentiators", ""))
        return {"module_fit": fits, "differentiators": diffs[:6] or ["Unified Fusion data model"],
                "gaps": [f["requirement"] for f in fits if f["fit"] != "strong"][:4],
                "overall_fit_score": min(score, 97)}


class CompetitorIntelAgent(BaseAgent):
    key, name = "competitor_intelligence", "Competitor Intelligence Agent"
    collections = ["competitors"]
    retrieve_k = 6

    def retrieve_query(self, inputs):
        m = inputs.get("manifest", {})
        return "system integrator Oracle Fusion manufacturing " + " ".join(m.get("scope_modules", []))

    def build_prompt(self, inputs):
        return P.COMPETITOR_INTEL.format(rule=P.WEB_RULE,
                                         manifest=json.dumps(inputs.get("manifest", {})))

    def augment_context(self, kb, inputs, context, web):
        """KB-first; if coverage is thin, gap-fill via the governed MCP web search
        and cache the result back into the KB for reproducibility."""
        from core.web_search import maybe_gap_fill
        gf = maybe_gap_fill(kb, "competitors", self.retrieve_query(inputs), web)
        self._gap = gf
        if gf.get("triggered") and gf.get("text"):
            context += "\n\n[SOURCE: web_search]\n" + gf["text"]
        return context

    def local_payload(self, inputs, context, kb):
        comps = []
        for h in kb.retrieve("competitors", self.retrieve_query(inputs), k=8):
            sec = md_sections(h["text"])
            if not sec.get("strengths") and "web intel" not in h["text"].lower():
                continue
            comps.append({
                "name": sec.get("_title", h["source"]),
                "strengths": bullets(sec.get("strengths", "")),
                "weaknesses": bullets(sec.get("weaknesses", "")),
                "likely_play": sec.get("likely play", "").strip() or "Compete on price and delivery scale.",
                "source": h["source"],
            })
        gf = getattr(self, "_gap", {})
        note = ("Live web gap-fill triggered via MCP search; results cached to KB."
                if gf.get("triggered") and gf.get("results")
                else "Curated internal profiles only; KB coverage sufficient.")
        return {"competitors": comps, "freshness_note": note,
                "field_summary": f"{len(comps)} competitors profiled (internal + live gap-fill)."}


class BattlecardAgent(BaseAgent):
    key, name = "battlecard", "Battlecard Generator Agent"
    collections = ["case_studies"]

    def retrieve_query(self, inputs):
        return "oracle fusion manufacturing delivery proof"

    def build_prompt(self, inputs):
        return P.BATTLECARD.format(rule=P.GROUNDING_RULE,
                                   manifest=json.dumps(inputs.get("manifest", {})),
                                   oracle=json.dumps(inputs.get("oracle", {})),
                                   competitor=json.dumps(inputs.get("competitor", {})))

    def local_payload(self, inputs, context, kb):
        oracle = inputs.get("oracle", {})
        comp = inputs.get("competitor", {})
        vs = []
        for c in comp.get("competitors", []):
            vs.append({"competitor": c["name"],
                       "where_we_win": c.get("weaknesses", [])[:3] or ["Deeper Oracle Fusion specialization"],
                       "where_we_lose": c.get("strengths", [])[:2],
                       "counter": f"Neutralize {c['name']} by leading with manufacturing-specific proof."})
        proofs = []
        for h in kb.retrieve("case_studies", "manufacturing oracle fusion", k=3):
            proofs.append(md_sections(h["text"]).get("_title", h["source"]))
        return {"our_strengths": oracle.get("differentiators", [])[:5] or ["Oracle Fusion manufacturing depth"],
                "our_weaknesses": oracle.get("gaps", [])[:4] or ["Limited named MFG references in segment"],
                "vs_competitors": vs,
                "proof_points": proofs or ["Prior Oracle Fusion manufacturing go-lives"]}


class PositioningAgent(BaseAgent):
    key, name = "positioning", "Positioning & Messaging Agent"
    collections = ["case_studies", "win_loss"]

    def retrieve_query(self, inputs):
        return "win theme manufacturing transformation outcome"

    def build_prompt(self, inputs):
        return P.POSITIONING.format(rule=P.GROUNDING_RULE,
                                    manifest=json.dumps(inputs.get("manifest", {})),
                                    battlecard=json.dumps(inputs.get("battlecard", {})))

    def local_payload(self, inputs, context, kb):
        pillars, lessons = [], []
        for h in kb.retrieve("case_studies", self.retrieve_query(inputs), k=3):
            sec = md_sections(h["text"])
            pillars.append({"pillar": sec.get("_title", h["source"]),
                            "proof": (sec.get("outcome", "") or sec.get("summary", ""))[:160],
                            "source": h["source"]})
        wl = _load_winloss(kb)
        for r in wl:
            if r.get("outcome") == "lost" and r.get("reason"):
                lessons.append(f"Lost {r.get('client','a bid')} ({r.get('competitor','')}): {r['reason']}")
        return {"value_proposition": "Lowest-risk path to a unified Oracle Fusion manufacturing backbone, proven in comparable plants.",
                "win_themes": ["Manufacturing-specific delivery proof", "Single Fusion data model", "Fixed-risk migration"],
                "messaging_pillars": pillars,
                "lessons_from_past": lessons[:4] or ["insufficient_data"],
                "executive_summary": "Position on proven manufacturing outcomes and de-risked migration, not generic ERP scale."}


class GoNoGoAgent(BaseAgent):
    key, name = "go_nogo", "Go / No-Go Agent"
    collections = ["win_loss"]

    def retrieve_query(self, inputs):
        return "oracle fusion manufacturing bid outcome"

    def build_prompt(self, inputs):
        return P.GO_NOGO.format(rule=P.INTERNAL_ONLY_RULE,
                                manifest=json.dumps(inputs.get("manifest", {})),
                                oracle=json.dumps(inputs.get("oracle", {})),
                                competitor=json.dumps(inputs.get("competitor", {})))

    def local_payload(self, inputs, context, kb):
        oracle = inputs.get("oracle", {})
        comp = inputs.get("competitor", {})
        names = {c["name"] for c in comp.get("competitors", [])}
        wl = _load_winloss(kb)
        rel = [r for r in wl if r.get("competitor") in names] or wl
        wins = sum(1 for r in rel if r.get("outcome") == "won")
        base_rate = (wins / len(rel)) if rel else 0.5
        fit = oracle.get("overall_fit_score", 70) / 100.0
        prob = int(round(100 * (0.55 * fit + 0.45 * base_rate)))
        decision = "GO" if prob >= 60 else ("CONDITIONAL_GO" if prob >= 45 else "NO_GO")
        return {"win_probability": prob, "decision": decision,
                "drivers_positive": [f"Capability fit {oracle.get('overall_fit_score','?')}/100"] +
                                    (oracle.get("differentiators", [])[:2]),
                "drivers_negative": oracle.get("gaps", [])[:3] or ["Strong incumbent competition"],
                "historical_basis": f"Historical win rate vs this competitor set: {wins}/{len(rel)} bids.",
                "confidence": "high" if rel and len(rel) >= 3 else "medium"}


class RecommendationAgent(BaseAgent):
    key, name = "recommendation", "Recommendation & Outcomes Agent"

    def build_prompt(self, inputs):
        return P.RECOMMENDATION.format(rule=P.GROUNDING_RULE,
                                       manifest=json.dumps(inputs.get("manifest", {})),
                                       battlecard=json.dumps(inputs.get("battlecard", {})),
                                       positioning=json.dumps(inputs.get("positioning", {})),
                                       go_nogo=json.dumps(inputs.get("go_nogo", {})))

    def local_payload(self, inputs, context, kb):
        bc = inputs.get("battlecard", {})
        gng = inputs.get("go_nogo", {})
        gaps = list(dict.fromkeys((bc.get("our_weaknesses", []) + gng.get("drivers_negative", []))))[:5]
        actions = []
        roles = ["Pursuit Lead", "Solution Architect", "Delivery Lead", "Sales"]
        for i, g in enumerate(gaps):
            actions.append({"action": f"Close gap: {g}", "owner_role": roles[i % len(roles)],
                            "priority": "high" if i < 2 else "medium", "closes_gap": g})
        return {"summary": gng.get("historical_basis", "Synthesised pursuit recommendation."),
                "gaps": gaps,
                "action_items": actions,
                "expected_probability_lift": "Closing the high-priority gaps materially improves the baseline win probability.",
                "final_recommendation": f"{gng.get('decision','CONDITIONAL_GO')} \u2014 pursue with the action plan above."}


def _load_winloss(kb) -> List[Dict]:
    out = []
    for d in kb.docs.get("win_loss", []):
        try:
            data = json.loads(d.text)
            out += data if isinstance(data, list) else [data]
        except json.JSONDecodeError:
            continue
    return out


ALL_AGENTS = {a.key: a for a in [
    RFPUnderstandingAgent(), OracleCapabilityAgent(), CompetitorIntelAgent(),
    BattlecardAgent(), PositioningAgent(), GoNoGoAgent(), RecommendationAgent(),
]}
