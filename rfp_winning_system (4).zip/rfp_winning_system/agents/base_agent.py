"""Base agent: builds prompt, retrieves grounding context, calls the provider,
parses JSON. In local mode it injects a deterministic grounded payload."""
from __future__ import annotations
import json
import re
from typing import Dict, List

from core.llm_provider import LocalProvider

MODULES = ["Financials", "SCM", "Manufacturing", "Procurement", "Inventory",
           "Order Management", "Maintenance", "Quality", "PPM", "HCM",
           "Product Lifecycle", "Cost Management"]


def md_sections(text: str) -> Dict[str, str]:
    """Parse '## Section' blocks from a markdown doc into {section: body}."""
    out, cur, buf = {}, None, []
    title = ""
    for line in text.splitlines():
        if line.startswith("# ") and not line.startswith("## "):
            title = line[2:].strip()
        elif line.startswith("## "):
            if cur is not None:
                out[cur] = "\n".join(buf).strip()
            cur, buf = line[3:].strip().lower(), []
        elif cur is not None:
            buf.append(line)
    if cur is not None:
        out[cur] = "\n".join(buf).strip()
    out["_title"] = title
    return out


def bullets(body: str) -> List[str]:
    return [re.sub(r"^[-*]\s*", "", ln).strip()
            for ln in body.splitlines() if ln.strip().startswith(("-", "*"))]


class BaseAgent:
    key = "base"
    name = "Base Agent"
    collections: List[str] = []
    retrieve_k = 3

    def retrieve_query(self, inputs: Dict) -> str:
        return ""

    def build_prompt(self, inputs: Dict) -> str:
        raise NotImplementedError

    def local_payload(self, inputs: Dict, context: str, kb) -> Dict:
        return {}

    def parse(self, raw: str) -> Dict:
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            m = re.search(r"\{.*\}", raw or "", re.S)
            if m:
                try:
                    return json.loads(m.group(0))
                except json.JSONDecodeError:
                    pass
            return {"text": raw}

    def _context(self, kb, inputs: Dict) -> str:
        q = self.retrieve_query(inputs)
        blocks = [kb.context_block(c, q, k=self.retrieve_k) for c in self.collections]
        return "\n\n".join(b for b in blocks if b)

    def augment_context(self, kb, inputs: Dict, context: str, web) -> str:
        """Hook for live gap-fill. Default: no change. Overridden by agents that
        may search the web (via the MCP tool) when the KB lacks coverage."""
        return context

    def run(self, provider, kb, inputs: Dict, web=None) -> Dict:
        if web is None:
            from core.web_search import get_web_search
            web = get_web_search()
        context = self._context(kb, inputs) if self.collections else ""
        context = self.augment_context(kb, inputs, context, web)
        prompt = self.build_prompt(inputs)
        if isinstance(provider, LocalProvider):
            payload = self.local_payload(inputs, context, kb)
            prompt += "\n<LOCAL_SPEC>" + json.dumps({"payload": payload}) + "</LOCAL_SPEC>"
        raw = provider.generate(self.key, prompt, context)
        content = self.parse(raw)
        sources = sorted(set(re.findall(r"\[SOURCE: ([^\]]+)\]", context)))
        return {"agent": self.key, "name": self.name, "content": content,
                "sources": sources, "ok": True}
