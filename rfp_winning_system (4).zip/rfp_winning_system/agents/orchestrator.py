"""Orchestrates the 4-phase pipeline. Agents within a phase run in parallel;
each agent call is failure-isolated so one error degrades gracefully."""
from __future__ import annotations
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Optional

from agents.pipeline_agents import ALL_AGENTS
from core.knowledge_base import KnowledgeBase
from core.llm_provider import get_provider
from core.web_search import get_web_search
from core import report_saver
import config

PHASES = [
    ["rfp_understanding"],
    ["oracle_capability", "competitor_intelligence"],
    ["battlecard", "positioning", "go_nogo"],
    ["recommendation"],
]


class Orchestrator:
    def __init__(self, provider=None, kb: Optional[KnowledgeBase] = None):
        self.provider = provider or get_provider()
        self.web = get_web_search()
        self.kb = kb or KnowledgeBase(
            config.DATA_DIR,
            ["competitors", "win_loss", "oracle_capability", "case_studies"],
        )

    def _run_agent(self, key: str, inputs: Dict) -> Dict:
        try:
            return ALL_AGENTS[key].run(self.provider, self.kb, inputs, web=self.web)
        except Exception as e:  # noqa: BLE001 - isolate failures per agent
            return {"agent": key, "name": ALL_AGENTS[key].name, "ok": False,
                    "error": f"{type(e).__name__}: {e}", "trace": traceback.format_exc(),
                    "content": {"error": "agent_failed"}}

    def run(self, rfp_text: str, job_id: Optional[str] = None, jobs=None) -> Dict:
        results: Dict[str, Dict] = {}

        def content(k):
            r = results.get(k, {})
            return r.get("content", {}) if r.get("ok") else {}

        for i, phase in enumerate(PHASES, 1):
            if jobs and job_id:
                jobs.update(job_id, status="running", phase=i)
            inputs_by_agent = {
                "rfp_understanding": {"rfp_text": rfp_text},
                "oracle_capability": {"manifest": content("rfp_understanding")},
                "competitor_intelligence": {"manifest": content("rfp_understanding")},
                "battlecard": {"manifest": content("rfp_understanding"),
                               "oracle": content("oracle_capability"),
                               "competitor": content("competitor_intelligence")},
                "positioning": {"manifest": content("rfp_understanding"),
                                "battlecard": content("battlecard")},
                "go_nogo": {"manifest": content("rfp_understanding"),
                            "oracle": content("oracle_capability"),
                            "competitor": content("competitor_intelligence")},
                "recommendation": {"manifest": content("rfp_understanding"),
                                   "battlecard": content("battlecard"),
                                   "positioning": content("positioning"),
                                   "go_nogo": content("go_nogo")},
            }
            if jobs and job_id:
                for k in phase:
                    jobs.set_agent(job_id, k, "running")
            with ThreadPoolExecutor(max_workers=len(phase)) as ex:
                futs = {ex.submit(self._run_agent, k, inputs_by_agent[k]): k for k in phase}
                for fut in futs:
                    k = futs[fut]
                    res = fut.result()
                    results[k] = res
                    if job_id:
                        report_saver.save(job_id, k, res)
                    if jobs and job_id:
                        jobs.set_agent(job_id, k, "done" if res.get("ok") else "failed")
                        jobs.set_result(job_id, k, res)
        if jobs and job_id:
            jobs.update(job_id, status="complete")
        return results
