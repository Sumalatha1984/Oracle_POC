# Midwest Auto Parts Fusion Manufacturing Go-Live
## Summary
Replaced aging on-prem ERP with Oracle Fusion Manufacturing, SCM and Financials across 4 plants.
## Outcome
On-time go-live, 18% reduction in inventory carrying cost, real-time WIP visibility in 6 months.
