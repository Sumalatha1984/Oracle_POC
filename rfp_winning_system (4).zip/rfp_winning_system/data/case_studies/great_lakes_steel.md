# Great Lakes Steel Smart Factory
## Summary
Oracle Fusion Manufacturing plus Maintenance with IoT-driven condition-based maintenance.
## Outcome
12% less unplanned downtime; maintenance and production on one platform.
