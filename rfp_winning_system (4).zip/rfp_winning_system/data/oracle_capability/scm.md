# Oracle Fusion Cloud SCM
## Capabilities
- Supply planning, demand management, order management
- Inventory and logistics, global trade
- Supply-chain orchestration and collaboration
## Differentiators
- Unified planning and execution on one cloud
- Real-time supply/demand signals across plants
