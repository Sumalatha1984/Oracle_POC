# Oracle Fusion Cloud Manufacturing
## Capabilities
- Discrete, process and mixed-mode manufacturing
- Work definitions, work orders, production scheduling
- Shop-floor execution, IoT/Maintenance integration
- Real-time WIP, costing and quality integration
## Differentiators
- Single Fusion data model across SCM, Manufacturing and Financials
- Embedded analytics and real-time costing on one platform
- Native integration with Maintenance and Quality
