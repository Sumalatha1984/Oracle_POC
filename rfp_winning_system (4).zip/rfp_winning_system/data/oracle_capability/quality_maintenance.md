# Oracle Fusion Quality and Maintenance
## Capabilities
- Quality inspection plans, nonconformance, corrective action
- Asset maintenance, preventive and condition-based work orders
## Differentiators
- Quality and Maintenance native to the manufacturing flow, not bolted on
