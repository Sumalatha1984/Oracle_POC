# Oracle Fusion Cloud Procurement
## Capabilities
- Source-to-pay, supplier qualification, contracts
- Self-service requisitioning and approvals
## Differentiators
- Procurement tied directly to inventory and manufacturing demand
