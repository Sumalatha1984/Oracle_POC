# Oracle Fusion Cloud Financials
## Capabilities
- General ledger, payables, receivables, assets
- Multi-entity, multi-currency, statutory reporting
- Real-time cost and margin visibility
## Differentiators
- Finance and operations on the same data model
- Continuous close and embedded controls
