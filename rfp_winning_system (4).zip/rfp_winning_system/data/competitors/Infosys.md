# Infosys
## Strengths
- Mature Oracle Fusion delivery with reusable assets
- Strong change-management and training offerings
- Good mid-market manufacturing references
## Weaknesses
- Premium pricing versus other SIs
- Thinner shop-floor / MES integration experience
- Capacity contention on parallel large programs
## Likely play
Lead with platform assets and a polished transformation narrative.
