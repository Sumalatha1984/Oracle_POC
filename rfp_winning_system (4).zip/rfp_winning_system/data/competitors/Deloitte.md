# Deloitte
## Strengths
- Strong Oracle alliance status and tax/finance depth
- Industry-aligned manufacturing teams
- Robust risk and controls capability
## Weaknesses
- Finance-led; manufacturing ops can be secondary
- Premium rates
- Heavier governance overhead
## Likely play
Anchor on finance transformation and compliance, extend into operations.
