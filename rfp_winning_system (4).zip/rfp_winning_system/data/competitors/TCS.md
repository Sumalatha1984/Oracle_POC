# TCS
## Strengths
- Very large Oracle Cloud practice and global delivery scale
- Aggressive commercial pricing on large multi-year programs
- Strong presence in manufacturing and automotive accounts
## Weaknesses
- Perceived as delivery-factory; less consultative on industry nuance
- High consultant rotation reported on long programs
- Slower to bring manufacturing-specific accelerators
## Likely play
Compete on price and global scale, bundling AMS to lock multi-year value.
