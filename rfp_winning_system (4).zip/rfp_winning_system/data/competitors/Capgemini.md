# Capgemini
## Strengths
- Strong European manufacturing and engineering heritage
- Intelligent-industry / smart-factory positioning
- Competitive blended rates
## Weaknesses
- Less dominant Oracle Fusion brand recognition in some regions
- Variable delivery consistency across geographies
## Likely play
Differentiate on smart-factory and OT/IT convergence story.
