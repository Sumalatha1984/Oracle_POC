# IBM
## Strengths
- Strong systems integration and hybrid-cloud heritage
- AI (watsonx) and automation positioning
- Enterprise infrastructure credibility
## Weaknesses
- Oracle Fusion apps practice smaller than pure Oracle SIs
- Higher complexity perception
## Likely play
Bundle Oracle Fusion with hybrid-cloud and AI automation messaging.
