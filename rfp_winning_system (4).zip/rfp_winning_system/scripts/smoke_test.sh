#!/usr/bin/env bash
# One-command end-to-end check (offline, no credentials needed).
set -e
cd "$(dirname "$0")/.."
export PROVIDER_MODE=local
echo "== running unit + end-to-end tests =="
python -m pytest -q
echo "== running pipeline on the sample RFP =="
python -m scripts.run_cli samples/sample_rfp.txt
