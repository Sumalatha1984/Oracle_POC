"""CLI runner: python -m scripts.run_cli <rfp_file>  (offline end-to-end)."""
import sys, json
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from agents.orchestrator import Orchestrator
from utils import file_parser

def main():
    if len(sys.argv) < 2:
        print("usage: python -m scripts.run_cli <rfp_file>"); sys.exit(1)
    text = file_parser.parse(sys.argv[1])
    results = Orchestrator().run(text)
    gng = results["go_nogo"]["content"]
    print("\n=== SUMMARY ===")
    print("Win probability :", gng.get("win_probability"))
    print("Decision        :", gng.get("decision"))
    print("Basis           :", gng.get("historical_basis"))
    print("Competitors     :", [c["name"] for c in results["competitor_intelligence"]["content"]["competitors"]])
    print("Action items    :", len(results["recommendation"]["content"]["action_items"]))
    ok = all(r["ok"] for r in results.values())
    print("All agents ok   :", ok)
    sys.exit(0 if ok else 2)

if __name__ == "__main__":
    main()
