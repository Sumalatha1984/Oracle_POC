"""HTTP routes. Analysis runs as a background job; the UI polls /status."""
from __future__ import annotations
import threading
from pathlib import Path

from flask import Blueprint, render_template, request, jsonify, abort
from werkzeug.utils import secure_filename

import config
from core.job_store import JOBS
from agents.orchestrator import Orchestrator
from utils import file_parser

bp = Blueprint("main", __name__)
ALLOWED = {".txt", ".md", ".pdf", ".docx"}


@bp.get("/")
def index():
    return render_template("index.html", mode=config.PROVIDER_MODE)


@bp.post("/analyze")
def analyze():
    rfp_text = ""
    if "file" in request.files and request.files["file"].filename:
        f = request.files["file"]
        name = secure_filename(f.filename)
        if Path(name).suffix.lower() not in ALLOWED:
            return jsonify({"error": "unsupported file type"}), 400
        dest = config.UPLOAD_DIR / name
        f.save(dest)
        try:
            rfp_text = file_parser.parse(str(dest))
        except Exception as e:  # noqa: BLE001
            return jsonify({"error": f"could not parse file: {e}"}), 400
    else:
        rfp_text = (request.form.get("rfp_text") or request.json.get("rfp_text", "") if request.is_json
                    else request.form.get("rfp_text", ""))
    if not rfp_text or len(rfp_text.strip()) < 30:
        return jsonify({"error": "provide an RFP file or paste at least a paragraph of text"}), 400

    job_id = JOBS.create()

    def worker():
        try:
            Orchestrator().run(rfp_text, job_id=job_id, jobs=JOBS)
        except Exception as e:  # noqa: BLE001
            JOBS.update(job_id, status="error", error=str(e))

    threading.Thread(target=worker, daemon=True).start()
    return jsonify({"job_id": job_id})


@bp.get("/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        abort(404)
    return jsonify(job)


@bp.get("/report/<job_id>")
def report(job_id):
    job = JOBS.get(job_id)
    if not job:
        abort(404)
    from core import report_html
    return report_html.render_fragment(job.get("results", {}))


@bp.get("/report/<job_id>/download")
def report_download(job_id):
    job = JOBS.get(job_id)
    if not job:
        abort(404)
    from core import report_html
    from flask import Response
    doc = report_html.render_document(job.get("results", {}))
    return Response(doc, mimetype="text/html",
                    headers={"Content-Disposition": f"attachment; filename=rfp_analysis_{job_id}.html"})


@bp.get("/health")
def health():
    return jsonify({"status": "ok", "mode": config.PROVIDER_MODE})
