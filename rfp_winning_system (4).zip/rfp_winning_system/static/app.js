const $ = (id) => document.getElementById(id);
const AGENTS = ["rfp_understanding","oracle_capability","competitor_intelligence",
  "battlecard","positioning","go_nogo","recommendation"];
let pollTimer = null, jobId = null;

$("run").addEventListener("click", start);

async function start(){
  $("msg").textContent=""; $("run").disabled=true; $("results").hidden=true;
  const fd = new FormData();
  const file = $("file").files[0];
  if(file) fd.append("file", file); else fd.append("rfp_text", $("rfp_text").value);
  let res;
  try{ res = await (await fetch("/analyze",{method:"POST",body:fd})).json(); }
  catch(e){ return fail("network error"); }
  if(res.error) return fail(res.error);
  jobId = res.job_id;
  $("progress").hidden=false; renderAgents({});
  poll();
}
function fail(m){ $("msg").textContent=m; $("run").disabled=false; }

function poll(){
  clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    const job = await (await fetch("/status/"+jobId)).json();
    renderAgents(job.agents||{});
    if(job.status==="complete"||job.status==="error"){
      clearInterval(pollTimer); $("run").disabled=false;
      if(job.status==="error") return fail(job.error||"run error");
      await showReport();
    }
  }, 700);
}
function renderAgents(states){
  $("agents").innerHTML = AGENTS.map(a=>{
    const s = states[a]||"queued";
    return `<li><span>${label(a)}</span><span class="badge ${s}">${s}</span></li>`;
  }).join("");
}
async function showReport(){
  const html = await (await fetch("/report/"+jobId)).text();
  $("report").innerHTML = html;
  $("download").href = "/report/"+jobId+"/download";
  $("results").hidden=false;
  $("results").scrollIntoView({behavior:"smooth"});
}
function label(a){return a.replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase());}
