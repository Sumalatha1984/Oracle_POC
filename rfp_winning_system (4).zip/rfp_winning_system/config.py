"""Central configuration. All settings come from environment / .env."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent

PROVIDER_MODE = os.getenv("PROVIDER_MODE", "local").strip().lower()

BLUEVERSE = {
    "base_url": os.getenv("BLUEVERSE_BASE_URL", ""),
    "token": os.getenv("BLUEVERSE_TOKEN", ""),
    "space_name": os.getenv("BLUEVERSE_SPACE_NAME", ""),
    "timeout": int(os.getenv("BLUEVERSE_TIMEOUT", "120")),
    "max_retries": int(os.getenv("BLUEVERSE_MAX_RETRIES", "3")),
}

# Logical agent name -> Blueverse flow id (env-driven)
FLOW_IDS = {
    "rfp_understanding": os.getenv("FLOW_RFP_UNDERSTANDING", ""),
    "oracle_capability": os.getenv("FLOW_ORACLE_CAPABILITY", ""),
    "competitor_intelligence": os.getenv("FLOW_COMPETITOR_INTEL", ""),
    "battlecard": os.getenv("FLOW_BATTLECARD", ""),
    "positioning": os.getenv("FLOW_POSITIONING", ""),
    "go_nogo": os.getenv("FLOW_GO_NOGO", ""),
    "recommendation": os.getenv("FLOW_RECOMMENDATION", ""),
}

DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR = BASE_DIR / "uploads"
SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "dev-only-key")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))

for d in (OUTPUT_DIR, UPLOAD_DIR):
    d.mkdir(exist_ok=True)

# ---- Hybrid grounding: web search via the Blueverse MCP connector ----
# Web search is a governed MCP tool (e.g. DuckDuckGo) used for gap-fill / freshness.
# It NEVER feeds Go/No-Go; the win probability stays on internal win/loss data.
ENABLE_WEB_SEARCH = os.getenv("ENABLE_WEB_SEARCH", "true").strip().lower() == "true"
# local = deterministic stub (offline tests/demo) ; blueverse_mcp = call the MCP search tool
WEB_SEARCH_MODE = os.getenv("WEB_SEARCH_MODE", "local" if PROVIDER_MODE == "local" else "blueverse_mcp")
MCP_SEARCH_URL = os.getenv("MCP_SEARCH_URL", "")          # Blueverse MCP DuckDuckGo tool endpoint
MCP_SEARCH_TOOL = os.getenv("MCP_SEARCH_TOOL", "duckduckgo_search")
GAP_SCORE_THRESHOLD = float(os.getenv("GAP_SCORE_THRESHOLD", "0.05"))  # below this KB coverage => gap-fill
CACHE_WEB_RESULTS = os.getenv("CACHE_WEB_RESULTS", "true").strip().lower() == "true"

# ---- Real-model testing (PROVIDER_MODE=llm) ----
# Exercise your actual prompts against a real model without Blueverse.
# Ollama (local, offline): LLM_BASE_URL=http://localhost:11434/v1, LLM_MODEL=llama3.1, no key.
LLM = {
    "base_url": os.getenv("LLM_BASE_URL", "http://localhost:11434/v1"),
    "api_key": os.getenv("LLM_API_KEY", ""),
    "model": os.getenv("LLM_MODEL", "llama3.1"),
    "timeout": int(os.getenv("LLM_TIMEOUT", "120")),
    "max_retries": int(os.getenv("LLM_MAX_RETRIES", "2")),
    "json_mode": os.getenv("LLM_JSON_MODE", "true").strip().lower() == "true",
}

# ---- Multi-query best-match + freshness ----
WEB_SEARCH_QUERIES = int(os.getenv("WEB_SEARCH_QUERIES", "3"))      # varied queries per gap-fill (2-4)
WEB_CACHE_FRESHNESS_DAYS = int(os.getenv("WEB_CACHE_FRESHNESS_DAYS", "30"))  # re-fetch cached web data older than this
