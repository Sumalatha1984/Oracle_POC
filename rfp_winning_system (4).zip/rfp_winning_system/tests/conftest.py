import os, sys
os.environ["PROVIDER_MODE"] = "local"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
