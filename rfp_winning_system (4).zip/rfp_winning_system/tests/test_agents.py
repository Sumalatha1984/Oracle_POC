import config
from core.knowledge_base import KnowledgeBase
from core.llm_provider import LocalProvider
from agents.pipeline_agents import (RFPUnderstandingAgent, CompetitorIntelAgent,
    OracleCapabilityAgent, GoNoGoAgent)

KB = KnowledgeBase(config.DATA_DIR, ["competitors","win_loss","oracle_capability","case_studies"])
PROV = LocalProvider()
RFP = open(config.BASE_DIR / "samples/sample_rfp.txt").read()

def test_rfp_understanding_outputs_manifest():
    r = RFPUnderstandingAgent().run(PROV, KB, {"rfp_text": RFP})
    c = r["content"]
    assert r["ok"] and "scope_modules" in c and c["must_have"]

def test_competitor_intel_is_grounded():
    r = CompetitorIntelAgent().run(PROV, KB, {"manifest": {"scope_modules":["Manufacturing"]}})
    names = [c["name"] for c in r["content"]["competitors"]]
    assert "TCS" in names and r["sources"]

def test_go_nogo_probability_in_range():
    manifest = {"scope_modules":["Manufacturing"]}
    oracle = OracleCapabilityAgent().run(PROV, KB, {"manifest": manifest})["content"]
    comp = CompetitorIntelAgent().run(PROV, KB, {"manifest": manifest})["content"]
    r = GoNoGoAgent().run(PROV, KB, {"manifest":manifest,"oracle":oracle,"competitor":comp})
    p = r["content"]["win_probability"]
    assert 0 <= p <= 100 and r["content"]["decision"] in ("GO","CONDITIONAL_GO","NO_GO")
