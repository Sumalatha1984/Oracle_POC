import config
from agents.orchestrator import Orchestrator

RFP = open(config.BASE_DIR / "samples/sample_rfp.txt").read()

def test_full_pipeline_runs_all_agents():
    results = Orchestrator().run(RFP)
    for key in ["rfp_understanding","oracle_capability","competitor_intelligence",
                "battlecard","positioning","go_nogo","recommendation"]:
        assert key in results, f"missing {key}"
        assert results[key]["ok"], f"{key} failed: {results[key].get('error')}"

def test_recommendation_has_actions():
    results = Orchestrator().run(RFP)
    rec = results["recommendation"]["content"]
    assert rec["action_items"] and rec["final_recommendation"]

def test_failure_isolation(monkeypatch):
    import agents.pipeline_agents as pa
    orig = pa.CompetitorIntelAgent.local_payload
    def boom(self, *a, **k): raise RuntimeError("simulated failure")
    monkeypatch.setattr(pa.CompetitorIntelAgent, "local_payload", boom)
    results = Orchestrator().run(RFP)
    assert results["competitor_intelligence"]["ok"] is False
    # downstream still completes
    assert results["recommendation"]["ok"] is True
    monkeypatch.setattr(pa.CompetitorIntelAgent, "local_payload", orig)
