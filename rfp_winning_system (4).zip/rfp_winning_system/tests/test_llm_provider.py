import json, types
import core.llm_provider as lp

def test_llm_provider_builds_and_parses(monkeypatch):
    captured = {}
    class FakeResp:
        def raise_for_status(self): pass
        def json(self): return {"choices":[{"message":{"content":'{"win_probability":55}'}}]}
    def fake_post(url, json=None, headers=None, timeout=None):
        captured["url"]=url; captured["payload"]=json; return FakeResp()
    monkeypatch.setattr(lp.requests, "post", fake_post)
    p = lp.LLMProvider({"base_url":"https://api.openai.com/v1","api_key":"sk-x","model":"gpt-4o-mini","timeout":10,"max_retries":1,"json_mode":True})
    out = p.generate("go_nogo", "system prompt here", "GROUNDING")
    assert "/chat/completions" in captured["url"]
    assert captured["payload"]["messages"][0]["role"]=="system"
    assert captured["payload"]["response_format"]["type"]=="json_object"
    assert json.loads(out)["win_probability"]==55
