import config
from core.knowledge_base import KnowledgeBase

KB = KnowledgeBase(config.DATA_DIR, ["competitors","win_loss","oracle_capability","case_studies"])

def test_collections_loaded():
    stats = KB.stats()
    assert stats["competitors"] >= 6
    assert stats["oracle_capability"] >= 4
    assert stats["case_studies"] >= 3
    assert stats["win_loss"] >= 1

def test_retrieve_ranks_relevant_doc():
    hits = KB.retrieve("competitors", "lowest price global scale automotive", k=1)
    assert hits and hits[0]["score"] > 0

def test_context_block_has_sources():
    block = KB.context_block("oracle_capability", "shop floor manufacturing work order", k=2)
    assert "[SOURCE:" in block
