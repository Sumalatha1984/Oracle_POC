"""Thread-safe in-memory job store with disk snapshots, enabling async runs
with real progress polling instead of one long blocking request."""
from __future__ import annotations
import json
import threading
import time
import uuid
from pathlib import Path
from typing import Dict, Optional

import config


class JobStore:
    def __init__(self):
        self._jobs: Dict[str, Dict] = {}
        self._lock = threading.Lock()

    def create(self) -> str:
        job_id = uuid.uuid4().hex[:12]
        with self._lock:
            self._jobs[job_id] = {
                "id": job_id, "status": "queued", "created": time.time(),
                "phase": None, "agents": {}, "results": {}, "error": None,
            }
        return job_id

    def update(self, job_id: str, **fields) -> None:
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id].update(fields)
                self._snapshot(job_id)

    def set_agent(self, job_id: str, agent: str, state: str) -> None:
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id]["agents"][agent] = state
                self._snapshot(job_id)

    def set_result(self, job_id: str, agent: str, result: Dict) -> None:
        with self._lock:
            if job_id in self._jobs:
                self._jobs[job_id]["results"][agent] = result
                self._snapshot(job_id)

    def get(self, job_id: str) -> Optional[Dict]:
        with self._lock:
            return json.loads(json.dumps(self._jobs.get(job_id))) if job_id in self._jobs else None

    def _snapshot(self, job_id: str) -> None:
        d = config.OUTPUT_DIR / job_id
        d.mkdir(exist_ok=True)
        (d / "job.json").write_text(json.dumps(self._jobs[job_id], indent=2), encoding="utf-8")


JOBS = JobStore()
