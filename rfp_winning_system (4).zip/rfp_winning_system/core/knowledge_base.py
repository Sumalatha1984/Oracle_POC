"""Offline RAG over the seeded knowledge base.

This is the grounding layer. At runtime agents retrieve relevant chunks from
curated internal documents (data/*) instead of hitting the internet. Retrieval
is a dependency-free TF-IDF cosine ranker so the whole system runs offline.

In production the same interface is backed by Blueverse's vector DB / an MCP
tool; agents call `retrieve()` exactly the same way.
"""
from __future__ import annotations
import math
import re
from collections import Counter
from pathlib import Path
from typing import List, Dict


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


class _Doc:
    def __init__(self, doc_id: str, source: str, text: str):
        self.id = doc_id
        self.source = source
        self.text = text
        self.tokens = _tokenize(text)
        self.tf = Counter(self.tokens)


class KnowledgeBase:
    """Loads markdown/text docs from a folder set and ranks them by TF-IDF."""

    def __init__(self, data_dir: Path, collections: List[str]):
        self.data_dir = Path(data_dir)
        self.collections = collections
        self.docs: Dict[str, List[_Doc]] = {c: [] for c in collections}
        self.idf: Dict[str, Dict[str, float]] = {}
        self._load()

    def _load(self) -> None:
        for coll in self.collections:
            folder = self.data_dir / coll
            docs: List[_Doc] = []
            if folder.exists():
                for fp in sorted(folder.glob("*")):
                    if fp.suffix.lower() in (".md", ".txt", ".json"):
                        txt = fp.read_text(encoding="utf-8", errors="ignore")
                        docs.append(_Doc(fp.stem, str(fp.name), txt))
            self.docs[coll] = docs
            self.idf[coll] = self._compute_idf(docs)

    @staticmethod
    def _compute_idf(docs: List[_Doc]) -> Dict[str, float]:
        n = len(docs) or 1
        df: Counter = Counter()
        for d in docs:
            for term in set(d.tokens):
                df[term] += 1
        return {t: math.log((n + 1) / (c + 1)) + 1.0 for t, c in df.items()}

    def _score(self, query_tokens: List[str], doc: _Doc, idf: Dict[str, float]) -> float:
        if not doc.tokens:
            return 0.0
        q = Counter(query_tokens)
        score = 0.0
        for term, qf in q.items():
            if term in doc.tf:
                w = idf.get(term, 1.0)
                score += (qf * w) * (doc.tf[term] * w)
        norm = math.sqrt(sum(v * v for v in doc.tf.values())) or 1.0
        return score / norm

    def retrieve(self, collection: str, query: str, k: int = 3) -> List[Dict]:
        """Return top-k docs from a collection as [{source, text, score}]."""
        docs = self.docs.get(collection, [])
        idf = self.idf.get(collection, {})
        qt = _tokenize(query)
        ranked = sorted(
            ({"source": d.source, "text": d.text, "score": self._score(qt, d, idf)} for d in docs),
            key=lambda x: x["score"], reverse=True,
        )
        return [r for r in ranked if r["score"] > 0][:k] or [
            {"source": d.source, "text": d.text, "score": 0.0} for d in docs[:k]
        ]

    def context_block(self, collection: str, query: str, k: int = 3, max_chars: int = 4000) -> str:
        """Concatenated, source-labelled context for prompting."""
        hits = self.retrieve(collection, query, k)
        parts = []
        for h in hits:
            parts.append(f"[SOURCE: {h['source']}]\n{h['text'].strip()}")
        block = "\n\n---\n\n".join(parts)
        return block[:max_chars]

    def cache_document(self, collection: str, name: str, text: str) -> None:
        """Write a new document into a collection (e.g. a web-search result) and
        refresh the in-memory index so it is immediately retrievable and reused
        on future runs. This is the cache-back-to-KB step for live gap-fill."""
        if collection not in self.docs:
            self.docs[collection] = []
            self.collections.append(collection)
        folder = self.data_dir / collection
        try:
            folder.mkdir(parents=True, exist_ok=True)
            (folder / f"{name}.md").write_text(text, encoding="utf-8")
        except OSError:
            pass  # read-only FS: still cache in memory for this process
        self.docs[collection] = [d for d in self.docs[collection] if d.id != name]
        self.docs[collection].append(_Doc(name, f"{name}.md", text))
        self.idf[collection] = self._compute_idf(self.docs[collection])

    def stats(self) -> Dict[str, int]:
        return {c: len(self.docs[c]) for c in self.collections}
