"""Crisp, human-readable HTML report renderer.

Single source of truth for how results are shown: used both for the in-app
results view and the downloadable report. Turns the agents' JSON into a clean,
judge-ready document (executive summary, competitor comparison table,
capability fit, battlecard, positioning, decision, action plan)."""
from __future__ import annotations
import html
from typing import Dict, List

def e(x) -> str:
    return html.escape(str(x if x is not None else ""))

def _list(items: List, empty="\u2014") -> str:
    items = [i for i in (items or []) if str(i).strip() and str(i) != "insufficient_data"]
    if not items:
        return f'<span class="muted">{empty}</span>'
    return "<ul>" + "".join(f"<li>{e(i)}</li>" for i in items) + "</ul>"

def _chips(items: List) -> str:
    return "".join(f'<span class="chip">{e(i)}</span>' for i in (items or []) if str(i).strip())

def _fit_badge(fit) -> str:
    cls = {"strong": "ok", "partial": "warn", "gap": "bad"}.get(str(fit).lower(), "neutral")
    return f'<span class="badge {cls}">{e(fit)}</span>'

def _decision_badge(d) -> str:
    cls = {"GO": "ok", "CONDITIONAL_GO": "warn", "NO_GO": "bad"}.get(str(d).upper(), "neutral")
    return f'<span class="badge {cls} lg">{e(d)}</span>'

def _prio_badge(p) -> str:
    cls = {"high": "bad", "medium": "warn", "low": "neutral"}.get(str(p).lower(), "neutral")
    return f'<span class="badge {cls}">{e(p)}</span>'

def _card(title, body, sources=None) -> str:
    src = f'<div class="src">grounded sources: {e(", ".join(sources))}</div>' if sources else ""
    return f'<section class="card"><h2>{e(title)}</h2>{body}{src}</section>'

def _content(results, key) -> Dict:
    r = results.get(key) or {}
    return r.get("content") or {} if r.get("ok", True) else {}

def render(results: Dict) -> str:
    gng = _content(results, "go_nogo")
    rec = _content(results, "recommendation")
    comp = _content(results, "competitor_intelligence")
    oracle = _content(results, "oracle_capability")
    bc = _content(results, "battlecard")
    pos = _content(results, "positioning")
    rfp = _content(results, "rfp_understanding")

    prob = gng.get("win_probability", "\u2014")
    decision = gng.get("decision", "\u2014")
    parts = []

    # ---- Executive summary banner ----
    parts.append(f"""
    <section class="hero">
      <div class="prob"><div class="num">{e(prob)}%</div><div class="lbl">Win probability</div></div>
      <div class="heroR">
        <div class="decwrap">{_decision_badge(decision)}</div>
        <p class="finalrec">{e(rec.get("final_recommendation", ""))}</p>
        <div class="metarow">
          <span><b>{len(comp.get("competitors", []))}</b> competitors analysed</span>
          <span>Capability fit <b>{e(oracle.get("overall_fit_score","\u2014"))}/100</b></span>
          <span>Confidence <b>{e(gng.get("confidence","\u2014"))}</b></span>
        </div>
        <div class="basis">{e(gng.get("historical_basis",""))}</div>
      </div>
    </section>""")

    # ---- Competitor comparison (centerpiece) ----
    rows = ""
    for c in comp.get("competitors", []):
        rows += f"""<tr><td class="nm">{e(c.get('name'))}</td>
          <td>{_list(c.get('strengths'))}</td>
          <td>{_list(c.get('weaknesses'))}</td>
          <td>{e(c.get('likely_play'))}</td>
          <td class="src-cell">{e(c.get('source'))}</td></tr>"""
    comp_body = f"""
      <p class="note">{e(comp.get('freshness_note',''))}</p>
      <table class="cmp"><thead><tr><th>Competitor</th><th>Strengths</th><th>Weaknesses</th><th>Likely play</th><th>Source</th></tr></thead>
      <tbody>{rows or '<tr><td colspan=5 class=muted>No competitors</td></tr>'}</tbody></table>"""
    parts.append(_card("Competitor comparison", comp_body, results.get("competitor_intelligence", {}).get("sources")))

    # ---- Oracle capability fit ----
    mf = ""
    for m in oracle.get("module_fit", []):
        mf += f"<tr><td>{e(m.get('requirement'))}</td><td>{e(m.get('oracle_module'))}</td><td>{_fit_badge(m.get('fit'))}</td></tr>"
    oracle_body = f"""
      <div class="score">Overall fit <b>{e(oracle.get('overall_fit_score','\u2014'))}/100</b></div>
      <table class="cmp"><thead><tr><th>Requirement</th><th>Oracle module</th><th>Fit</th></tr></thead><tbody>{mf}</tbody></table>
      <div class="two"><div><h4>Differentiators</h4>{_list(oracle.get('differentiators'))}</div>
      <div><h4>Gaps</h4>{_list(oracle.get('gaps'))}</div></div>"""
    parts.append(_card("Oracle Fusion capability fit", oracle_body, results.get("oracle_capability", {}).get("sources")))

    # ---- Battlecard ----
    vs = ""
    for v in bc.get("vs_competitors", []):
        vs += f"""<tr><td class="nm">{e(v.get('competitor'))}</td>
          <td>{_list(v.get('where_we_win'))}</td><td>{_list(v.get('where_we_lose'))}</td>
          <td>{e(v.get('counter'))}</td></tr>"""
    bc_body = f"""
      <div class="two"><div><h4>Our strengths</h4>{_list(bc.get('our_strengths'))}</div>
      <div><h4>Our weaknesses</h4>{_list(bc.get('our_weaknesses'))}</div></div>
      <h4>Head-to-head</h4>
      <table class="cmp"><thead><tr><th>Competitor</th><th>Where we win</th><th>Where we lose</th><th>Counter</th></tr></thead>
      <tbody>{vs}</tbody></table>"""
    parts.append(_card("Battlecard \u2014 honest head-to-head", bc_body))

    # ---- Positioning ----
    pillars = "".join(f"<tr><td class='nm'>{e(p.get('pillar'))}</td><td>{e(p.get('proof'))}</td><td class='src-cell'>{e(p.get('source'))}</td></tr>"
                      for p in pos.get("messaging_pillars", []))
    pos_body = f"""
      <p class="vp">{e(pos.get('value_proposition'))}</p>
      <h4>Win themes</h4><div class="chips">{_chips(pos.get('win_themes'))}</div>
      <h4>Messaging pillars</h4><table class="cmp"><thead><tr><th>Pillar</th><th>Proof</th><th>Source</th></tr></thead><tbody>{pillars}</tbody></table>
      <h4>Lessons from past bids</h4>{_list(pos.get('lessons_from_past'))}"""
    parts.append(_card("Winning positioning", pos_body, results.get("positioning", {}).get("sources")))

    # ---- Go / No-Go ----
    gng_body = f"""
      <div class="two"><div><h4>Positive drivers</h4>{_list(gng.get('drivers_positive'))}</div>
      <div><h4>Negative drivers</h4>{_list(gng.get('drivers_negative'))}</div></div>
      <div class="basis2"><b>Historical basis:</b> {e(gng.get('historical_basis'))}</div>"""
    parts.append(_card("Go / No-Go decision", gng_body, results.get("go_nogo", {}).get("sources")))

    # ---- Recommendation ----
    acts = "".join(f"<tr><td>{e(a.get('action'))}</td><td>{e(a.get('owner_role'))}</td><td>{_prio_badge(a.get('priority'))}</td></tr>"
                   for a in rec.get("action_items", []))
    rec_body = f"""
      <p>{e(rec.get('summary'))}</p>
      <h4>Gaps to close</h4>{_list(rec.get('gaps'))}
      <h4>Action plan</h4><table class="cmp"><thead><tr><th>Action</th><th>Owner</th><th>Priority</th></tr></thead><tbody>{acts}</tbody></table>
      <div class="basis2"><b>Expected lift:</b> {e(rec.get('expected_probability_lift'))}</div>
      <div class="finalbox">{e(rec.get('final_recommendation'))}</div>"""
    parts.append(_card("Recommendation & action plan", rec_body))

    # ---- RFP summary (compact, last) ----
    rfp_body = f"""
      <p class="vp">{e(rfp.get('opportunity'))}</p>
      <div class="two"><div><h4>Scope modules</h4><div class="chips">{_chips(rfp.get('scope_modules'))}</div>
        <h4>Must have</h4>{_list(rfp.get('must_have'))}</div>
      <div><h4>Evaluation factors</h4>{_list(rfp.get('evaluation_factors'))}
        <h4>Risk flags</h4>{_list(rfp.get('risk_flags'))}</div></div>"""
    parts.append(_card("RFP summary", rfp_body))

    return "".join(parts)


REPORT_CSS = """
.rep{font-family:Arial,Helvetica,sans-serif;color:#1c2b26;max-width:1000px;margin:0 auto}
.rep h2{font-size:16px;color:#0F6E56;margin:0 0 12px;border-bottom:2px solid #E1F5EE;padding-bottom:6px}
.rep h4{font-size:12.5px;color:#15302A;margin:14px 0 6px;text-transform:uppercase;letter-spacing:.03em}
.rep .card{background:#fff;border:1px solid #e2e7e3;border-radius:12px;padding:18px 20px;margin:0 0 16px;box-shadow:0 1px 4px rgba(0,0,0,.04)}
.rep ul{margin:4px 0;padding-left:18px}.rep li{margin:2px 0;font-size:13px}
.rep .muted{color:#9aa3a0}.rep p{font-size:13.5px;line-height:1.5}

.rep .hero{display:flex;background:#0B3B30;color:#fff;border-radius:14px;padding:22px 26px;margin-bottom:18px}
.rep .prob{text-align:center;min-width:150px;border-right:1px solid rgba(255,255,255,.18);padding-right:22px;margin-right:22px}
.rep .prob .num{font-size:54px;font-weight:800;color:#E8A33D;line-height:1}
.rep .prob .lbl{font-size:12px;color:#BFE6D8;margin-top:4px}
.rep .heroR{flex:1}.rep .decwrap{margin-bottom:8px}
.rep .finalrec{font-size:15px;font-weight:600;color:#fff;margin:4px 0 10px}
.rep .metarow{font-size:12.5px;color:#CFE9DF;margin-bottom:6px}
.rep .metarow span{margin-right:22px}
.rep .metarow b{color:#fff}.rep .basis{font-size:12px;color:#9FC9BB}
.rep .badge{display:inline-block;font-size:11px;font-weight:700;padding:2px 9px;border-radius:10px;text-transform:uppercase;letter-spacing:.03em}
.rep .badge.lg{font-size:14px;padding:4px 14px}
.rep .badge.ok{background:#E1F5EE;color:#0F6E56}.rep .badge.warn{background:#FBEFD6;color:#9A6B00}
.rep .badge.bad{background:#FBE3E1;color:#B3261E}.rep .badge.neutral{background:#ECEEEC;color:#5d6b66}
.rep table.cmp{width:100%;border-collapse:collapse;margin:6px 0 4px;font-size:12.5px}
.rep table.cmp th{background:#0F6E56;color:#fff;text-align:left;padding:7px 10px;font-size:11.5px}
.rep table.cmp td{border:1px solid #e4e9e5;padding:8px 10px;vertical-align:top}
.rep table.cmp tr:nth-child(even) td{background:#f7faf8}
.rep td.nm{font-weight:700;color:#0F6E56;white-space:nowrap}.rep td.src-cell{font-size:11px;color:#8a938f}
.rep .two{display:flex}.rep .two>div{flex:1;padding-right:22px}
.rep .chips{display:flex;flex-wrap:wrap;gap:6px}
.rep .chip{background:#E1F5EE;color:#0F6E56;font-size:11.5px;padding:3px 10px;border-radius:12px;font-weight:600}
.rep .score{font-size:14px;margin-bottom:4px}.rep .score b{color:#0F6E56}
.rep .vp{font-size:14.5px;font-weight:600;color:#15302A}
.rep .note{font-size:12px;color:#5d6b66;font-style:italic;margin:0 0 8px}
.rep .basis2{font-size:12.5px;background:#f3f6f4;border-radius:8px;padding:8px 12px;margin-top:8px}
.rep .finalbox{margin-top:12px;background:#E1F5EE;border-left:4px solid #0F6E56;padding:10px 14px;border-radius:6px;font-weight:700;color:#0B3B30}
.rep .src{font-size:10.5px;color:#9aa3a0;margin-top:10px}
"""

def render_document(results: Dict, title="RFP-Winning System \u2014 Analysis Report") -> str:
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>{e(title)}</title>
<style>body{{background:#f4f7f5;margin:0;padding:28px}}{REPORT_CSS}</style></head>
<body><div class="rep"><h1 style="color:#0F6E56;font-size:22px;margin:0 0 16px">{e(title)}</h1>
{render(results)}</div></body></html>"""

def render_fragment(results: Dict) -> str:
    return f'<style>{REPORT_CSS}</style><div class="rep">{render(results)}</div>'
