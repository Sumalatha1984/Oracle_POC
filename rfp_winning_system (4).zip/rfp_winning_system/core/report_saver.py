"""Persist each agent's output to disk as .json and .txt for audit/reuse."""
from __future__ import annotations
import json
from pathlib import Path
from typing import Dict
import config


def save(job_id: str, agent: str, result: Dict) -> None:
    d = config.OUTPUT_DIR / job_id
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{agent}.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    text = result.get("content") if isinstance(result, dict) else None
    if isinstance(text, (dict, list)):
        text = json.dumps(text, indent=2, ensure_ascii=False)
    (d / f"{agent}.txt").write_text(str(text or json.dumps(result, indent=2, ensure_ascii=False)),
                                    encoding="utf-8")
