const $ = (id) => document.getElementById(id);
const AGENTS = ["rfp_understanding","oracle_capability","competitor_intelligence",
  "battlecard","positioning","go_nogo","recommendation"];
let pollTimer = null, lastResults = {};

$("run").addEventListener("click", start);

async function start(){
  $("msg").textContent=""; $("run").disabled=true;
  const fd = new FormData();
  const file = $("file").files[0];
  if(file) fd.append("file", file);
  else fd.append("rfp_text", $("rfp_text").value);
  let res;
  try{ res = await (await fetch("/analyze",{method:"POST",body:fd})).json(); }
  catch(e){ fail("network error"); return; }
  if(res.error){ fail(res.error); return; }
  $("progress").hidden=false; renderAgents({});
  poll(res.job_id);
}
function fail(m){ $("msg").textContent=m; $("run").disabled=false; }

function poll(jobId){
  clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    const job = await (await fetch("/status/"+jobId)).json();
    renderAgents(job.agents||{});
    lastResults = job.results||{};
    if(job.status==="complete"||job.status==="error"){
      clearInterval(pollTimer); $("run").disabled=false;
      renderTabs(); if(job.status==="error") fail(job.error||"run error");
    }
  }, 700);
}
function renderAgents(states){
  $("agents").innerHTML = AGENTS.map(a=>{
    const s = states[a]||"queued";
    return `<li><span>${label(a)}</span><span class="badge ${s}">${s}</span></li>`;
  }).join("");
}
function renderTabs(){
  $("results").hidden=false;
  const keys = AGENTS.filter(a=>lastResults[a]);
  $("tabs").innerHTML = keys.map((a,i)=>`<button data-k="${a}" class="${i===0?'active':''}">${label(a)}</button>`).join("");
  $("tabs").querySelectorAll("button").forEach(b=>b.onclick=()=>{
    $("tabs").querySelectorAll("button").forEach(x=>x.classList.remove("active"));
    b.classList.add("active"); show(b.dataset.k);
  });
  if(keys.length) show(keys[0]);
}
function show(k){
  const r = lastResults[k]||{};
  const body = r.ok===false ? {error:r.error} : r.content;
  const src = (r.sources&&r.sources.length)?`\n\n// grounded sources: ${r.sources.join(", ")}`:"";
  $("output").textContent = JSON.stringify(body,null,2)+src;
}
function label(a){return a.replace(/_/g," ").replace(/\b\w/g,c=>c.toUpperCase());}
