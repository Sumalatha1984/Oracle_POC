"""Central configuration. All settings come from environment / .env."""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()
BASE_DIR = Path(__file__).resolve().parent

PROVIDER_MODE = os.getenv("PROVIDER_MODE", "local").strip().lower()

BLUEVERSE = {
    "base_url": os.getenv("BLUEVERSE_BASE_URL", ""),
    "token": os.getenv("BLUEVERSE_TOKEN", ""),
    "space_name": os.getenv("BLUEVERSE_SPACE_NAME", ""),
    "timeout": int(os.getenv("BLUEVERSE_TIMEOUT", "120")),
    "max_retries": int(os.getenv("BLUEVERSE_MAX_RETRIES", "3")),
}

# Logical agent name -> Blueverse flow id (env-driven)
FLOW_IDS = {
    "rfp_understanding": os.getenv("FLOW_RFP_UNDERSTANDING", ""),
    "oracle_capability": os.getenv("FLOW_ORACLE_CAPABILITY", ""),
    "competitor_intelligence": os.getenv("FLOW_COMPETITOR_INTEL", ""),
    "battlecard": os.getenv("FLOW_BATTLECARD", ""),
    "positioning": os.getenv("FLOW_POSITIONING", ""),
    "go_nogo": os.getenv("FLOW_GO_NOGO", ""),
    "recommendation": os.getenv("FLOW_RECOMMENDATION", ""),
}

DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR = BASE_DIR / "uploads"
SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "dev-only-key")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "20"))

for d in (OUTPUT_DIR, UPLOAD_DIR):
    d.mkdir(exist_ok=True)
