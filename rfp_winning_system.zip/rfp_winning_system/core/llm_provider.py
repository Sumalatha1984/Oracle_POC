"""Pluggable LLM provider.

- BlueverseProvider: calls the real Blueverse Foundry chat endpoint (production).
- LocalProvider: deterministic, offline stand-in that synthesizes grounded JSON
  from the retrieved knowledge-base context so the full pipeline runs and is
  testable without any credentials or internet.

Both expose the same .generate(agent_key, prompt, context) -> str interface.
"""
from __future__ import annotations
import json
import time
import re
from typing import Dict

import requests

import config


class ProviderError(Exception):
    pass


class BlueverseProvider:
    """Production provider. Sends the agent prompt as the query to the
    pre-configured Blueverse agent (space_name + flowId)."""

    def __init__(self, cfg: Dict, flow_ids: Dict[str, str]):
        self.cfg = cfg
        self.flow_ids = flow_ids
        if not cfg.get("base_url") or not cfg.get("token"):
            raise ProviderError("Blueverse base_url/token not configured. Set them in .env.")

    def generate(self, agent_key: str, prompt: str, context: str = "") -> str:
        flow_id = self.flow_ids.get(agent_key, "")
        query = prompt if not context else f"{prompt}\n\nGROUNDING CONTEXT:\n{context}"
        payload = {
            "query": query,
            "space_name": self.cfg["space_name"],
            "flowId": flow_id,
        }
        headers = {
            "Authorization": f"Bearer {self.cfg['token']}",
            "Content-Type": "application/json",
        }
        last_err = None
        for attempt in range(1, self.cfg["max_retries"] + 1):
            try:
                r = requests.post(self.cfg["base_url"], json=payload,
                                  headers=headers, timeout=self.cfg["timeout"])
                r.raise_for_status()
                return self._extract(r.json())
            except Exception as e:  # noqa: BLE001
                last_err = e
                if attempt < self.cfg["max_retries"]:
                    time.sleep(min(2 ** attempt, 8))
        raise ProviderError(f"Blueverse call failed for {agent_key}: {last_err}")

    @staticmethod
    def _extract(body) -> str:
        """Pin-and-fallback extraction of the assistant text from the response."""
        if isinstance(body, str):
            return body
        if isinstance(body, dict):
            # Pin the documented key first, then fall back defensively.
            for key in ("answer", "response", "output", "result", "message", "text", "content"):
                v = body.get(key)
                if isinstance(v, str) and v.strip():
                    return v
                if isinstance(v, dict):
                    inner = v.get("content") or v.get("text")
                    if isinstance(inner, str) and inner.strip():
                        return inner
            data = body.get("data")
            if isinstance(data, dict):
                return BlueverseProvider._extract(data)
        return json.dumps(body)


class LocalProvider:
    """Offline deterministic provider. Each agent passes a JSON 'spec' inside the
    prompt under a <LOCAL_SPEC> tag; we render it into a grounded JSON answer.
    This keeps demo/test output reproducible and grounded on the seeded KB."""

    def generate(self, agent_key: str, prompt: str, context: str = "") -> str:
        spec = self._read_spec(prompt)
        # Echo back a structured, grounded JSON object the agents can parse.
        out = dict(spec.get("payload", {}))
        out["_grounded_sources"] = self._sources(context)
        out["_agent"] = agent_key
        return json.dumps(out, ensure_ascii=False, indent=2)

    @staticmethod
    def _read_spec(prompt: str) -> Dict:
        m = re.search(r"<LOCAL_SPEC>(.*?)</LOCAL_SPEC>", prompt, re.S)
        if not m:
            return {"payload": {"note": "no local spec supplied"}}
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            return {"payload": {"note": "invalid local spec"}}

    @staticmethod
    def _sources(context: str):
        return re.findall(r"\[SOURCE: ([^\]]+)\]", context or "")


def get_provider():
    if config.PROVIDER_MODE == "blueverse":
        return BlueverseProvider(config.BLUEVERSE, config.FLOW_IDS)
    return LocalProvider()
